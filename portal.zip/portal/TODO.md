# TODO - Refactor query & logika absensi (Admin Dashboard & Rekap)

## Step 1: Setup idempotent Alpa (Opsi 2)
- [ ] Pastikan tabel `presensi` memiliki UNIQUE KEY yang mencegah dobel per slot: `(id_mahasiswa, id_jadwal, tanggal)`

## Step 2: Perbaiki `admin/rekap.php` agar menampilkan seluruh riwayat
- [ ] Hapus `WHERE p.tanggal = CURDATE()` pada query default server-side
- [ ] Ubah query default menjadi historis (tanpa filter tanggal), tetap urut DESC, dengan LIMIT aman
- [ ] Pertahankan AJAX filter tanggal untuk pencarian historis

## Step 3: Perbaiki `admin/dashboard.php` agar ada daftar mahasiswa/jadwal hari ini
- [ ] Tambah query derived: daftar mahasiswa yang punya jadwal hari ini
- [ ] Gunakan LEFT JOIN presensi untuk status
- [ ] Jika belum ada presensi: tampilkan `Belum Absen` atau `Alpa` dengan rule `CURTIME() > jam_selesai`
- [ ] Pastikan daftar derived tidak melakukan INSERT

## Step 4: Kurangi tumpang tindih pemanggilan `periksaAlpaOtomatis`
- [ ] Tetap panggil di dashboard & rekap, tapi idempotentness harus terjamin via UNIQUE KEY

## Step 5: Testing manual
- [ ] Buka `admin/dashboard.php`, cek daftar status hari ini (Belum Absen/Alpa)
- [ ] Buka `admin/rekap.php`, cek data historis lintas hari tampil
- [ ] Tunggu refresh berulang, pastikan jumlah baris `Alpa` tidak dobel

