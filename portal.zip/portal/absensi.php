<?php
// ============================================================
// ABSENSI.PHP — Form Isi Presensi (Database Version)
// ============================================================
require_once 'koneksi.php';
require_once 'functions.php';

cekLogin();
periksaAlpaOtomatis($pdo);

$dataMahasiswa = getMahasiswa();
$idJadwal      = (int) ($_GET['id'] ?? 0);

// Validasi ID jadwal
if (!$idJadwal) {
    setFlash('Jadwal tidak valid.', 'error');
    header('Location: dashboard.php');
    exit;
}

// Ambil data jadwal (hanya milik kelas yg login)
$jadwal = getJadwalById($pdo, $idJadwal);
if (!$jadwal) {
    setFlash('Jadwal tidak ditemukan atau bukan jadwal kelas Anda.', 'error');
    header('Location: dashboard.php');
    exit;
}

$jamStatus   = statusJamJadwal($jadwal['jam_mulai'], $jadwal['jam_selesai']);
$presensiAda = getPresensiHariIni($pdo, $idJadwal);

// Validasi waktu — tolak akses di luar jam aktif
if ($jamStatus === 'belum') {
    setFlash('Absensi untuk mata kuliah ini belum dibuka. Dibuka pukul ' . fmtJam($jadwal['jam_mulai']) . ' WIB.', 'error');
    header('Location: dashboard.php');
    exit;
}
if ($jamStatus === 'selesai' && !$presensiAda) {
    setFlash('Waktu absensi sudah ditutup. Anda tercatat Alpa.', 'error');
    header('Location: dashboard.php');
    exit;
}

// Proses form POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_absensi']) && !$presensiAda) {
    $keterangan = trim($_POST['keterangan'] ?? '');
    $jenisIzin  = $_POST['jenis_izin'] ?? '';

    if ($keterangan !== '') {
        // Ada keterangan → Izin atau Sakit
        $status = ($jenisIzin === 'Sakit') ? 'Sakit' : 'Izin';
    } else {
        $status = 'Hadir';
    }

    if (simpanPresensi($pdo, $idJadwal, $status, $keterangan)) {
        setFlash('Absensi "' . $jadwal['nama_matkul'] . '" berhasil disimpan sebagai ' . $status . '!', 'success');
    } else {
        setFlash('Gagal menyimpan absensi. Silakan coba lagi.', 'error');
    }
    header('Location: dashboard.php');
    exit;
}

// Re-fetch setelah proses (jika ada)
$presensiAda = getPresensiHariIni($pdo, $idJadwal);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Form Absensi - Portal Mahasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @keyframes fadeInUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes scaleIn  { from{opacity:0;transform:scale(.9)} to{opacity:1;transform:scale(1)} }
        @keyframes checkPop { 0%{transform:scale(0)} 50%{transform:scale(1.2)} 100%{transform:scale(1)} }
        @keyframes gradientShift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        .animate-fade-in-up { animation:fadeInUp .5s ease-out forwards; }
        .animate-scale-in   { animation:scaleIn .4s ease-out forwards; }
        .animate-check-pop  { animation:checkPop .4s ease-out forwards; }
        .btn-submit {
            background:linear-gradient(135deg,#144A8C,#1F5DAA,#3B82F6);
            background-size:200% 200%;
            animation:gradientShift 3s ease infinite;
            transition:all .3s ease;
        }
        .btn-submit:hover { transform:translateY(-2px); box-shadow:0 10px 30px -5px rgba(31,93,170,.4); }
        .detail-row { transition:all .2s ease; }
        .detail-row:hover { background:rgba(59,130,246,.03); }
        .pattern-bg {
            background-image:radial-gradient(circle at 1px 1px,rgba(255,255,255,.08) 1px,transparent 0);
            background-size:20px 20px;
        }
    </style>
</head>
<body class="bg-gray-50 pb-6">
<div class="max-w-md mx-auto bg-white min-h-screen shadow-xl">

    <?php renderBackHeader('Form Absensi', 'Isi kehadiran Anda', 'dashboard.php'); ?>

    <main class="px-4 py-4 space-y-5">

        <!-- Kartu mahasiswa -->
        <div class="animate-fade-in-up" style="animation-delay:.05s;">
            <div class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] rounded-2xl p-4 text-white shadow-lg relative overflow-hidden pattern-bg">
                <div class="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                <div class="relative z-10 flex items-center gap-3">
                    <div class="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm border border-white/30 shrink-0">
                        <img src="<?php echo htmlspecialchars($dataMahasiswa['foto']); ?>" alt="Avatar" class="w-10 h-10 rounded-lg object-cover">
                    </div>
                    <div class="min-w-0">
                        <p class="text-xs text-blue-200">Mahasiswa</p>
                        <p class="font-bold text-sm truncate"><?php echo htmlspecialchars($dataMahasiswa['nama']); ?></p>
                        <p class="text-[10px] text-blue-300/80">NIM : <?php echo htmlspecialchars($dataMahasiswa['nim']); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($presensiAda): ?>
        <!-- Sudah absen — tampilkan ringkasan -->
        <div class="animate-scale-in" style="animation-delay:.1s;">
            <div class="bg-green-50 border-2 border-green-200 rounded-2xl p-6 text-center">
                <div class="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-check-pop">
                    <i class="fas fa-check text-white text-2xl"></i>
                </div>
                <h3 class="text-lg font-bold text-green-800 mb-1">Sudah Absen!</h3>
                <p class="text-sm text-green-600 mb-4">Kehadiran Anda sudah tercatat untuk mata kuliah ini.</p>

                <div class="bg-white rounded-xl p-4 text-left space-y-2 border border-green-100">
                    <?php
                        $stClass = statusKehadiranClass($presensiAda['status_kehadiran']);
                    ?>
                    <div class="flex justify-between items-center text-sm py-1 border-b border-gray-50">
                        <span class="text-gray-500">Status</span>
                        <span class="font-bold px-3 py-1 rounded-full text-xs <?php echo $stClass; ?>">
                            <?php echo $presensiAda['status_kehadiran']; ?>
                        </span>
                    </div>
                    <div class="flex justify-between text-sm py-1 border-b border-gray-50">
                        <span class="text-gray-500">Tanggal</span>
                        <span class="font-semibold text-gray-800"><?php echo formatTanggalIndo($presensiAda['tanggal']); ?></span>
                    </div>
                    <div class="flex justify-between text-sm py-1 border-b border-gray-50">
                        <span class="text-gray-500">Jam Dicatat</span>
                        <span class="font-semibold text-gray-800"><?php echo date('H:i', strtotime($presensiAda['waktu_pencatatan'])); ?></span>
                    </div>
                    <?php if (!empty($presensiAda['keterangan'])): ?>
                    <div class="pt-3 border-t border-gray-100 text-sm text-gray-600">
                        <p class="font-semibold text-gray-700 mb-1">Keterangan</p>
                        <p class="bg-gray-50 p-2.5 rounded-lg text-xs border border-gray-100">
                            <?php echo nl2br(htmlspecialchars($presensiAda['keterangan'])); ?>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>

                <a href="dashboard.php" class="inline-flex items-center gap-2 mt-5 px-6 py-2.5 bg-green-500 hover:bg-green-600 text-white font-medium rounded-xl transition-colors text-sm shadow-sm">
                    <i class="fas fa-arrow-left text-xs"></i> Kembali ke Dashboard
                </a>
            </div>
        </div>

        <?php else: ?>
        <!-- Detail mata kuliah -->
        <div class="animate-fade-in-up" style="animation-delay:.1s;">
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="flex items-center gap-2 mb-4">
                    <div class="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-book-open text-[#3B82F6] text-sm"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-800 text-sm">Detail Mata Kuliah</h3>
                        <p class="text-[10px] text-gray-400">Informasi jadwal kuliah hari ini</p>
                    </div>
                </div>
                <div class="space-y-0 rounded-xl overflow-hidden border border-gray-100">
                    <?php
                    $detailItems = [
                        ['icon'=>'fa-book',               'color'=>'bg-[#144A8C]/10 text-[#144A8C]', 'label'=>'Mata Kuliah',   'value'=>$jadwal['nama_matkul'] . ' (' . $jadwal['tipe'] . ')'],
                        ['icon'=>'far fa-clock',          'color'=>'bg-yellow-50 text-yellow-500',   'label'=>'Waktu',          'value'=>fmtJam($jadwal['jam_mulai']) . ' – ' . fmtJam($jadwal['jam_selesai']) . ' WIB'],
                        ['icon'=>'fa-door-open',          'color'=>'bg-green-50 text-green-500',     'label'=>'Ruangan',        'value'=>$jadwal['ruangan']],
                        ['icon'=>'fa-chalkboard-teacher', 'color'=>'bg-red-50 text-red-500',         'label'=>'Dosen Pengampu', 'value'=>trim($jadwal['gelar'] . ' ' . $jadwal['nama_dosen'])],
                    ];
                    foreach ($detailItems as $i => $item):
                        $border = $i < count($detailItems)-1 ? 'border-b border-gray-100' : '';
                    ?>
                    <div class="detail-row flex items-center justify-between px-4 py-3 <?php echo $border; ?>">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg <?php echo $item['color']; ?> flex items-center justify-center shrink-0">
                                <i class="fas <?php echo $item['icon']; ?> text-xs"></i>
                            </div>
                            <div>
                                <p class="text-[10px] text-gray-400 uppercase font-medium tracking-wide"><?php echo $item['label']; ?></p>
                                <p class="text-sm font-semibold text-gray-800"><?php echo htmlspecialchars($item['value']); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Form isi absensi -->
        <div class="animate-fade-in-up" style="animation-delay:.15s;">
            <form action="" method="POST" class="space-y-4">
                <input type="hidden" name="submit_absensi" value="1">

                <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                    <div class="flex items-center gap-2 mb-4">
                        <div class="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                            <i class="fas fa-clipboard-check text-[#3B82F6] text-sm"></i>
                        </div>
                        <div>
                            <h3 class="font-semibold text-gray-800 text-sm">Isi Kehadiran</h3>
                            <p class="text-[10px] text-gray-400">Tekan Hadir, atau isi keterangan jika Izin/Sakit.</p>
                        </div>
                    </div>

                    <!-- Jenis izin (hanya muncul jika ada keterangan) -->
                    <div class="mb-3">
                        <p class="text-[10px] text-gray-500 uppercase font-semibold tracking-wide mb-2">Jenis Ketidakhadiran (jika ada keterangan)</p>
                        <div class="flex gap-2">
                            <label class="flex-1 flex items-center gap-2 cursor-pointer bg-blue-50 border border-blue-200 rounded-xl p-3 hover:bg-blue-100 transition">
                                <input type="radio" name="jenis_izin" value="Izin" checked class="text-blue-600">
                                <span class="text-sm text-blue-700 font-medium">Izin</span>
                            </label>
                            <label class="flex-1 flex items-center gap-2 cursor-pointer bg-yellow-50 border border-yellow-200 rounded-xl p-3 hover:bg-yellow-100 transition">
                                <input type="radio" name="jenis_izin" value="Sakit" class="text-yellow-600">
                                <span class="text-sm text-yellow-700 font-medium">Sakit</span>
                            </label>
                        </div>
                        <p class="text-[10px] text-gray-400 mt-1">Diabaikan jika tidak ada keterangan (otomatis: Hadir).</p>
                    </div>

                    <div class="rounded-2xl border border-gray-200 p-4 bg-gray-50">
                        <p class="text-[10px] text-gray-500 uppercase font-semibold tracking-wide mb-2">Keterangan (opsional)</p>
                        <textarea name="keterangan" rows="4"
                                  class="w-full resize-none rounded-2xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-800 focus:border-[#1F5DAA] focus:outline-none focus:ring-2 focus:ring-[#1F5DAA]/10"
                                  placeholder="Tuliskan alasan jika Anda izin atau sakit. Kosongkan jika hadir."></textarea>
                        <p class="text-[10px] text-gray-400 mt-2">Mengisi keterangan akan mencatat status sebagai Izin atau Sakit.</p>
                    </div>
                </div>

                <button type="submit" class="btn-submit w-full text-white font-bold py-4 rounded-2xl shadow-lg text-sm flex items-center justify-center gap-2">
                    <i class="fas fa-hand-paper"></i> Hadir
                </button>

                <a href="dashboard.php" class="block w-full text-center py-3 text-gray-500 hover:text-gray-700 text-sm font-medium transition-colors">
                    <i class="fas fa-times mr-1 text-xs"></i> Batal
                </a>
            </form>
        </div>
        <?php endif; ?>

    </main>
</div>
</body>
</html>