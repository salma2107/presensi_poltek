<?php
// ============================================================
// admin/dashboard.php — Dashboard Admin
// Fitur: Statistik global hari ini + Live Log 10 presensi terbaru
// ============================================================
require_once 'includes/init.php';

// PEMICU OTOMATIS: Memastikan record Alpa tersimpan (idempotent via UNIQUE KEY)
// Tanpa ini, mahasiswa yang terlambat/absen tidak akan otomatis tercatat.
if (function_exists('periksaAlpaOtomatis')) {
    periksaAlpaOtomatis($pdo);
}


// ---- AJAX partial render untuk live log ----
if (isset($_GET['ajax_log']) && $_GET['ajax_log'] === '1') {
    header('Content-Type: application/json');
    try {
        // QUERY LIVE LOG: tampilkan hanya presensi yang benar-benar tercatat hari ini.
        // Auto-generated Alpa akan dicatat oleh periksaAlpaOtomatis() saat jam kursus telah lewat.
        $stmtLog = $pdo->prepare('
            SELECT
                p.waktu_pencatatan,
                p.status_kehadiran,
                p.keterangan,
                m.nama          AS nama_mahasiswa,
                m.nim,
                kj.nama_jurusan,
                kj.nama_kelas,
                mk.nama_matkul,
                d.nama_dosen,
                j.jam_mulai,
                j.jam_selesai,
                p.id_presensi
              FROM presensi p
              JOIN mahasiswa    m  ON p.id_mahasiswa = m.id_mahasiswa
              JOIN jadwal       j  ON p.id_jadwal    = j.id_jadwal
              JOIN mata_kuliah  mk ON j.id_matkul    = mk.id_matkul
              JOIN kelas_jurusan kj ON m.id_kelas   = kj.id_kelas
              JOIN dosen        d  ON j.id_dosen     = d.id_dosen
             WHERE p.tanggal = CURDATE()
             ORDER BY p.waktu_pencatatan DESC
             LIMIT 10
        ');

        $stmtLog->execute();
        $logs = $stmtLog->fetchAll();
        
        $output = '';
        if (empty($logs)) {
            $output .= '<tr>
                <td colspan="7" class="px-6 py-10 text-center text-gray-400">
                    <div class="flex flex-col items-center gap-2">
                        <i class="fas fa-inbox text-3xl mb-1"></i>
                        <p class="text-sm font-medium">Belum ada presensi hari ini</p>
                    </div>
                </td>
            </tr>';
        } else {
            foreach ($logs as $log) {
                $statusCls = match($log['status_kehadiran']) {
                    'Hadir' => 'bg-green-100 text-green-700',
                    'Izin'  => 'bg-blue-100 text-blue-700',
                    'Sakit' => 'bg-yellow-100 text-yellow-700',
                    default => 'bg-red-100 text-red-700',
                };
                $output .= '<tr class="hover:bg-gray-50/50 transition-colors border-b border-gray-100">';
                $output .= '<td class="px-6 py-4 font-mono text-gray-500 text-sm whitespace-nowrap">' . date('H:i', strtotime($log['waktu_pencatatan'])) . '</td>';
                $output .= '<td class="px-6 py-4"><p class="font-semibold text-sm text-gray-800 leading-tight">' . htmlspecialchars($log['nama_mahasiswa']) . '</p><p class="text-[11px] text-gray-400 mt-0.5">' . htmlspecialchars($log['nim']) . '</p></td>';
                $output .= '<td class="px-6 py-4 text-sm text-gray-600 leading-tight">' . htmlspecialchars($log['nama_jurusan']) . '<br><span class="text-[11px] text-gray-400">Kelas ' . htmlspecialchars($log['nama_kelas']) . '</span></td>';
                $output .= '<td class="px-6 py-4 text-sm font-medium text-gray-700 leading-tight">' . htmlspecialchars($log['nama_matkul']) . '<br><span class="text-[11px] text-gray-400 font-normal">' . htmlspecialchars($log['nama_dosen']) . '</span></td>';
                $output .= '<td class="px-6 py-4 font-mono text-xs text-gray-500 whitespace-nowrap">' . fmtJam($log['jam_mulai']) . ' – ' . fmtJam($log['jam_selesai']) . '</td>';
                $output .= '<td class="px-6 py-4 text-center whitespace-nowrap"><span class="' . $statusCls . ' text-xs font-semibold px-2.5 py-1 rounded-lg">' . $log['status_kehadiran'] . '</span></td>';
                $output .= '<td class="px-6 py-4 text-xs text-gray-500 max-w-[150px] truncate">' . htmlspecialchars($log['keterangan'] ?? '-') . '</td>';
                $output .= '</tr>';
            }
        }
        echo json_encode(['html' => $output]);
    } catch (PDOException $e) {
        echo json_encode(['html' => '<tr><td colspan="7" class="px-6 py-4 text-center text-red-500 text-sm">Gagal memuat data</td></tr>']);
    }
    exit;
}

$pageTitle = 'Dashboard';

// ---- Query 1: Statistik kehadiran hari ini (GROUP BY status) ----
$stmtStat = $pdo->prepare('
    SELECT status_kehadiran, COUNT(*) AS jumlah
      FROM presensi
     WHERE tanggal = CURDATE()
     GROUP BY status_kehadiran
');
$stmtStat->execute();
$rawStat  = $stmtStat->fetchAll();

$stat = ['Hadir' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0];
foreach ($rawStat as $row) {
    if (isset($stat[$row['status_kehadiran']])) {
        $stat[$row['status_kehadiran']] = (int) $row['jumlah'];
    }
}
$totalHariIni = array_sum($stat);

// ---- Query 2: Live Log 10 presensi terbaru hari ini ----
$stmtLog = $pdo->prepare('
    SELECT
        p.waktu_pencatatan,
        p.status_kehadiran,
        p.keterangan,
        m.nama          AS nama_mahasiswa,
        m.nim,
        kj.nama_jurusan,
        kj.nama_kelas,
        mk.nama_matkul,
        d.nama_dosen,
        j.jam_mulai,
        j.jam_selesai,
        p.id_presensi
      FROM presensi p
      JOIN mahasiswa    m  ON p.id_mahasiswa = m.id_mahasiswa
      JOIN jadwal       j  ON p.id_jadwal    = j.id_jadwal
      JOIN mata_kuliah  mk ON j.id_matkul    = mk.id_matkul
      JOIN kelas_jurusan kj ON m.id_kelas   = kj.id_kelas
      JOIN dosen        d  ON j.id_dosen     = d.id_dosen
     WHERE p.tanggal = CURDATE()
     ORDER BY p.waktu_pencatatan DESC
     LIMIT 10
');
$stmtLog->execute();
$liveLog = $stmtLog->fetchAll();

// ---- Query 3: Total mahasiswa terdaftar ----
$totalMhs  = $pdo->query('SELECT COUNT(*) FROM mahasiswa')->fetchColumn();

// ---- Query 4: Total jadwal hari ini (dari semua kelas) ----
$hariMap   = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu',7=>'Minggu'];
$hariStr   = $hariMap[(int)date('N')] ?? 'Senin';
$stmtJdwl  = $pdo->prepare('SELECT COUNT(*) FROM jadwal WHERE hari = ?');
$stmtJdwl->execute([$hariStr]);
$totalJadwalHariIni = $stmtJdwl->fetchColumn();

require_once 'includes/layout.php';
?>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <?php
    $cards = [
        ['label'=>'Hadir',     'val'=>$stat['Hadir'], 'icon'=>'fa-circle-check',    'from'=>'from-green-500',  'to'=>'to-green-600',  'light'=>'bg-green-50',  'text'=>'text-green-600'],
        ['label'=>'Izin',      'val'=>$stat['Izin'],  'icon'=>'fa-calendar-check',  'from'=>'from-blue-500',   'to'=>'to-blue-600',   'light'=>'bg-blue-50',   'text'=>'text-blue-600'],
        ['label'=>'Sakit',     'val'=>$stat['Sakit'], 'icon'=>'fa-notes-medical',   'from'=>'from-amber-500',  'to'=>'to-amber-600',  'light'=>'bg-amber-50',  'text'=>'text-amber-600'],
        ['label'=>'Alpa',      'val'=>$stat['Alpa'],  'icon'=>'fa-circle-xmark',    'from'=>'from-red-500',    'to'=>'to-red-600',    'light'=>'bg-red-50',    'text'=>'text-red-600'],
    ];
    foreach ($cards as $c): ?>
    <div class="stat-card">
        <div class="w-12 h-12 bg-gradient-to-br <?php echo $c['from'].' '.$c['to']; ?> rounded-xl flex items-center justify-center shrink-0 shadow-md">
            <i class="fas <?php echo $c['icon']; ?> text-white text-lg"></i>
        </div>
        <div>
            <p class="text-2xl font-bold text-gray-800"><?php echo $c['val']; ?></p>
            <p class="text-xs text-gray-500 font-medium"><?php echo $c['label']; ?> Hari Ini</p>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-4">
        <div class="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
            <i class="fas fa-users text-indigo-600"></i>
        </div>
        <div>
            <p class="text-xl font-bold text-gray-800"><?php echo $totalMhs; ?></p>
            <p class="text-xs text-gray-500">Total Mahasiswa</p>
        </div>
    </div>
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-4">
        <div class="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center">
            <i class="fas fa-calendar-day text-purple-600"></i>
        </div>
        <div>
            <p class="text-xl font-bold text-gray-800"><?php echo $totalJadwalHariIni; ?></p>
            <p class="text-xs text-gray-500">Jadwal <?php echo $hariStr; ?> Ini</p>
        </div>
    </div>
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-4">
        <div class="w-10 h-10 bg-teal-50 rounded-xl flex items-center justify-center">
            <i class="fas fa-chart-pie text-teal-600"></i>
        </div>
        <div>
            <p class="text-xl font-bold text-gray-800">
                <?php echo $totalHariIni > 0 ? round($stat['Hadir'] / $totalHariIni * 100, 1) : 0; ?>%
            </p>
            <p class="text-xs text-gray-500">Tingkat Kehadiran</p>
        </div>
    </div>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100">
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                <i class="fas fa-bolt text-blue-600 text-sm"></i>
            </div>
            <div>
                <h2 class="font-bold text-gray-800 text-sm">Live Log Presensi Hari Ini</h2>
                <p class="text-[11px] text-gray-400">10 entri terbaru — auto-refresh setiap 30 detik</p>
            </div>
        </div>
        <a href="rekap.php" class="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1">
            Lihat Semua <i class="fas fa-arrow-right text-[10px]"></i>
        </a>
    </div>

    <div class="overflow-x-auto thin-scroll">
        <table class="w-full text-left border-collapse">
            <thead class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white">
                <tr>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider">Waktu</th>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider">Nama / NIM</th>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider">Kelas</th>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider">Mata Kuliah</th>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider">Jam Kuliah</th>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Status</th>
                    <th class="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider">Keterangan</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 bg-white" id="liveLogBody">
                <?php if (empty($liveLog)): ?>
                <tr>
                    <td colspan="7" class="px-6 py-10 text-center text-gray-400">
                        <div class="flex flex-col items-center gap-2">
                            <i class="fas fa-inbox text-3xl mb-1"></i>
                            <p class="text-sm font-medium">Belum ada presensi hari ini</p>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($liveLog as $log):
                    $statusCls = match($log['status_kehadiran']) {
                        'Hadir' => 'bg-green-100 text-green-700',
                        'Izin'  => 'bg-blue-100 text-blue-700',
                        'Sakit' => 'bg-yellow-100 text-yellow-700',
                        default => 'bg-red-100 text-red-700',
                    };
                ?>
                <tr class="hover:bg-gray-50/50 transition-colors">
                    <td class="px-6 py-4 font-mono text-gray-500 text-sm whitespace-nowrap">
                        <?php echo date('H:i', strtotime($log['waktu_pencatatan'])); ?>
                    </td>
                    <td class="px-6 py-4">
                        <p class="font-semibold text-sm text-gray-800 leading-tight"><?php echo htmlspecialchars($log['nama_mahasiswa']); ?></p>
                        <p class="text-[11px] text-gray-400 mt-0.5"><?php echo htmlspecialchars($log['nim']); ?></p>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-600 leading-tight">
                        <?php echo htmlspecialchars($log['nama_jurusan']); ?><br>
                        <span class="text-[11px] text-gray-400">Kelas <?php echo htmlspecialchars($log['nama_kelas']); ?></span>
                    </td>
                    <td class="px-6 py-4 text-sm font-medium text-gray-700 leading-tight">
                        <p class="font-semibold"><?php echo htmlspecialchars($log['nama_matkul']); ?></p>
                        <p class="text-[11px] text-gray-400 font-normal mt-0.5"><?php echo htmlspecialchars($log['nama_dosen']); ?></p>
                    </td>
                    <td class="px-6 py-4 text-gray-500 font-mono text-xs whitespace-nowrap">
                        <?php echo fmtJam($log['jam_mulai']); ?> – <?php echo fmtJam($log['jam_selesai']); ?>
                    </td>
                    <td class="px-6 py-4 text-center whitespace-nowrap">
                        <span class="<?php echo $statusCls; ?> text-xs font-semibold px-2.5 py-1 rounded-lg">
                            <?php echo $log['status_kehadiran']; ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-gray-500 text-xs max-w-[150px] truncate">
                        <?php echo htmlspecialchars($log['keterangan'] ?? '-'); ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-5 py-3 bg-gray-50/60 border-t border-gray-100 text-[11px] text-gray-400 flex items-center gap-2">
        <span class="inline-block w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
        Live — terakhir diperbarui: <span id="lastRefresh"><?php echo date('H:i:s'); ?></span>
    </div>
</div>

<script>
setInterval(async function () {
    try {
        const res  = await fetch('dashboard.php?ajax_log=1', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        });
        
        if (res.status === 401) {
            return;
        }
        
        const data = await res.json();
        document.getElementById('liveLogBody').innerHTML = data.html;
        document.getElementById('lastRefresh').textContent = new Date().toLocaleTimeString('id-ID');
    } catch (e) {}
}, 30000);
</script>

<?php
require_once 'includes/layout_footer.php';
?>