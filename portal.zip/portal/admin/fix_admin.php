<?php
require_once '../koneksi.php'; // Sesuaikan arah file koneksi Anda

try {
    // TENTUKAN USERNAME & PASSWORD ADMIN ANDA DI SINI
    $username_admin = 'admin'; 
    $password_polos  = 'admin123'; 

    // Generate hash standard PHP yang valid untuk password_verify
    $password_hash = password_hash($password_polos, PASSWORD_DEFAULT);

    // Kueri ini akan memperbarui password jika user 'admin' sudah ada
    // Serta memastikan datanya masuk ke database dengan utuh
    $sql = "UPDATE admin SET password = ? WHERE username = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$password_hash, $username_admin]);

    if ($stmt->rowCount() > 0) {
        echo "<div style='font-family:sans-serif; padding:20px; color:#1e3a8a;'>";
        echo "<h2>✓ Berhasil Memperbarui Password Admin!</h2>";
        echo "Username: <b>{$username_admin}</b><br>";
        echo "Password Baru: <u>{$password_polos}</u><br><br>";
        echo "Hasil Hash di DB: <code style='background:#f1f5f9; padding:4px 8px; border-radius:4px;'>{$password_hash}</code><br><br>";
        echo "Silakan tes login kembali pada halaman admin Anda. Jangan lupa hapus file ini setelah berhasil.";
        echo "</div>";
    } else {
        // Jika username admin Anda ternyata bukan 'admin' melainkan nama lain, kueri di atas tidak akan merubah apapun.
        echo "Username '{$username_admin}' tidak ditemukan di tabel admin. Periksa kembali isi tabel Anda di phpMyAdmin.";
    }

} catch (PDOException $e) {
    echo "Gagal: " . $e->getMessage();
}