<?php
// ============================================================
// admin/includes/init.php
// Bootstrap file untuk setiap halaman admin:
//   1. Resolve path ke root project
//   2. Load koneksi PDO
//   3. Load semua helper functions
//   4. Cek autentikasi admin
//   5. Mulai session jika belum
// Cara pakai: require_once 'includes/init.php'; di baris pertama
// ============================================================

define('ADMIN_GUARD', true);          // Guard untuk layout.php
define('ROOT_PATH', dirname(__DIR__)); // = /portal_absensi_db

require_once __DIR__ . '/../../koneksi.php';
require_once __DIR__ . '/../../functions.php';

// ==========================================
// KUNCI PENGASINGAN ADMIN (TAMBAH DI SINI)
// ==========================================
// Jika admin sedang diakses, buang/unset semua variabel session milik mahasiswa
if (isset($_SESSION['id_admin'])) {
    unset($_SESSION['id_mahasiswa']);
    unset($_SESSION['nama']);
    unset($_SESSION['nim']);
    unset($_SESSION['id_kelas']);
    unset($_SESSION['nama_jurusan']);
    unset($_SESSION['nama_kelas']);
    unset($_SESSION['email']);
    unset($_SESSION['no_telepon']);
    unset($_SESSION['tanggal_lahir']);
    unset($_SESSION['tahun_masuk']);
}

// Cek autentikasi admin memastikan hanya admin yang sah boleh masuk
cekLoginAdmin();