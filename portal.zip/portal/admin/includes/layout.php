<?php
// ============================================================
// admin/includes/layout.php
// Komponen layout bersama: header, sidebar, CSS untuk admin panel
// Cara pakai: include 'includes/layout.php'; di setiap halaman admin
// ============================================================

// Pastikan tidak diakses langsung
if (!defined('ADMIN_GUARD')) {
    http_response_code(403);
    die('Akses langsung tidak diperbolehkan.');
}

$adminData   = getAdmin();
$currentPage = basename($_SERVER['PHP_SELF'], '.php'); // e.g. 'dashboard'

/**
 * Render alert dari session flash
 */
function adminFlash(): void {
    if (!isset($_SESSION['flash'])) return;
    $f  = $_SESSION['flash'];
    $is = $f['type'] === 'success';
    $c  = $is ? 'green' : 'red';
    echo '<div id="flashAlert" class="flex items-center gap-3 p-4 mb-6 rounded-xl border '
       . "bg-{$c}-50 border-{$c}-200 text-{$c}-800" . '">';
    echo '<i class="fas ' . ($is ? 'fa-check-circle' : 'fa-exclamation-circle') . ' text-lg"></i>';
    echo '<p class="text-sm font-medium">' . htmlspecialchars($f['message']) . '</p>';
    echo '<button onclick="this.parentElement.remove()" class="ml-auto text-' . $c . '-500 hover:text-' . $c . '-700"><i class="fas fa-times"></i></button>';
    echo '</div>';
    unset($_SESSION['flash']);
}

/**
 * Render sidebar item — aktif jika $page cocok dengan file saat ini
 */
function sidebarItem(string $page, string $icon, string $label, string $url): void {
    global $currentPage;
    $isActive = $currentPage === $page;
    $base = $isActive
        ? 'flex items-center gap-3 px-4 py-3 rounded-xl bg-blue-600 text-white font-semibold shadow-md'
        : 'flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-blue-50 hover:text-blue-700 transition-colors';
    echo "<a href=\"{$url}\" class=\"{$base}\">";
    echo "<i class=\"fas {$icon} w-5 text-center\"></i>";
    echo "<span class=\"text-sm\">{$label}</span>";
    echo '</a>';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle ?? 'Admin Panel'); ?> — Portal Presensi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* Transisi sidebar mobile */
        #sidebar { transition: transform .25s ease; }
        @media (max-width:1023px) {
            #sidebar { transform: translateX(-100%); }
            #sidebar.open { transform: translateX(0); }
        }
        /* Scrollbar tipis untuk tabel */
        .thin-scroll::-webkit-scrollbar { height: 5px; width: 5px; }
        .thin-scroll::-webkit-scrollbar-track { background: #f1f5f9; }
        .thin-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 99px; }
        /* Badge status */
        .badge-hadir  { @apply bg-green-100 text-green-700; }
        .badge-izin   { @apply bg-blue-100 text-blue-700; }
        .badge-sakit  { @apply bg-yellow-100 text-yellow-700; }
        .badge-alpa   { @apply bg-red-100 text-red-700; }
        /* Animasi fade */
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        .fade-in { animation: fadeIn .35s ease forwards; }
        /* Input admin */
        .admin-input {
            @apply w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition;
        }
        .admin-btn-primary {
            @apply inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow transition;
        }
        .admin-btn-danger {
            @apply inline-flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow transition;
        }
        .admin-btn-success {
            @apply inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow transition;
        }
        .admin-btn-warning {
            @apply inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow transition;
        }
        .admin-btn-ghost {
            @apply inline-flex items-center gap-2 border border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-medium px-4 py-2 rounded-lg transition;
        }
        .stat-card {
            @apply bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex items-center gap-4;
        }
        .table-head th {
            @apply px-4 py-3 text-left text-xs font-semibold text-white uppercase tracking-wider whitespace-nowrap;
        }
        .table-body td {
            @apply px-4 py-3 text-sm text-gray-700 whitespace-nowrap;
        }
        .table-body tr:hover { background:#f8fafc; }
    </style>
</head>
<body class="bg-gray-50 font-sans">

<!-- Overlay sidebar mobile -->
<div id="sidebarOverlay" onclick="closeSidebar()"
     class="fixed inset-0 bg-black/40 z-30 hidden lg:hidden"></div>

<!-- ============ SIDEBAR ============ -->
<aside id="sidebar"
       class="fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-200 z-40 flex flex-col shadow-lg">
    <!-- Logo -->
    <div class="flex items-center gap-3 px-5 py-5 border-b border-gray-100">
        <div class="w-9 h-9 bg-gradient-to-br from-[#144A8C] to-[#3B82F6] rounded-xl flex items-center justify-center shrink-0 shadow-md">
            <i class="fas fa-shield-halved text-white text-sm"></i>
        </div>
        <div>
            <p class="text-sm font-bold text-[#144A8C] leading-tight">Admin Panel</p>
            <p class="text-[10px] text-gray-400">Portal Presensi</p>
        </div>
    </div>

    <!-- Info admin -->
    <div class="px-4 py-3 border-b border-gray-100 bg-blue-50/50">
        <p class="text-xs text-gray-500">Login sebagai</p>
        <p class="text-sm font-bold text-blue-700"><?php echo htmlspecialchars($adminData['nama']); ?></p>
        <span class="inline-block mt-0.5 text-[10px] bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full font-medium">
            <?php echo ucfirst($adminData['role']); ?>
        </span>
    </div>

    <!-- Navigasi -->
    <nav class="flex-1 px-3 py-4 space-y-1 overflow-y-auto thin-scroll">
        <p class="text-[10px] text-gray-400 uppercase font-semibold px-2 mb-2 tracking-wider">Menu Utama</p>
        <?php
        sidebarItem('dashboard', 'fa-gauge-high',     'Dashboard',       'dashboard.php');
        sidebarItem('rekap',     'fa-table-list',     'Rekap Presensi',  'rekap.php');
        ?>

        <p class="text-[10px] text-gray-400 uppercase font-semibold px-2 mt-4 mb-2 tracking-wider">Kelola Data</p>
        <?php
        sidebarItem('mahasiswa', 'fa-users',          'Data Mahasiswa',  'mahasiswa.php');
        sidebarItem('jadwal',    'fa-calendar-days',  'Jadwal Kuliah',   'jadwal.php');
        sidebarItem('profile',   'fa-user-shield',    'Profil Admin',    'profile.php');
        ?>
    </nav>

    <!-- Logout -->
    <div class="px-3 py-4 border-t border-gray-100">
        <a href="logout.php"
           class="flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors">
            <i class="fas fa-sign-out-alt w-5 text-center"></i>
            <span class="text-sm font-medium">Keluar</span>
        </a>
    </div>
</aside>

<!-- ============ MAIN WRAPPER ============ -->
<div class="lg:ml-64 min-h-screen flex flex-col">

    <!-- Top bar -->
    <header class="bg-white border-b border-gray-200 sticky top-0 z-20 shadow-sm">
        <div class="flex items-center justify-between px-5 py-3">
            <div class="flex items-center gap-3">
                <!-- Hamburger (mobile) -->
                <button onclick="openSidebar()"
                        class="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 text-gray-600">
                    <i class="fas fa-bars"></i>
                </button>
                <div>
                    <h1 class="text-base font-bold text-gray-800 leading-tight">
                        <?php echo htmlspecialchars($pageTitle ?? 'Dashboard'); ?>
                    </h1>
                    <p class="text-[11px] text-gray-400">
                        <?php echo date('l, d F Y'); ?>
                    </p>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <div class="text-right hidden sm:block">
                    <p class="text-xs font-semibold text-gray-700"><?php echo htmlspecialchars($adminData['nama']); ?></p>
                    <p class="text-[10px] text-gray-400"><?php echo ucfirst($adminData['role']); ?></p>
                </div>
                <div class="w-9 h-9 rounded-xl overflow-hidden shadow-sm">
                    <img src="../asset/logo.png" alt="Logo Admin" class="w-full h-full object-cover">
                </div>
            </div>
        </div>
    </header>

    <!-- Konten halaman -->
    <main class="flex-1 p-5 lg:p-6 fade-in">
        <?php adminFlash(); ?>