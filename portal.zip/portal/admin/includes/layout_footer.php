</main><!-- end main -->
</div><!-- end main wrapper -->

<script>
// ---- Sidebar toggle (mobile) ----
function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('sidebarOverlay').classList.remove('hidden');
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.add('hidden');
}

// ---- Konfirmasi hapus universal ----
function confirmDelete(form, msg) {
    msg = msg || 'Apakah Anda yakin ingin menghapus data ini? Tindakan tidak bisa dibatalkan.';
    if (confirm(msg)) form.submit();
    return false;
}

// ---- Tutup flash alert otomatis setelah 4 detik ----
setTimeout(function () {
    const el = document.getElementById('flashAlert');
    if (el) el.style.opacity = '0', setTimeout(() => el.remove(), 400);
    el && (el.style.transition = 'opacity .4s');
}, 4000);
</script>
</body>
</html>