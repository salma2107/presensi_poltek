<?php
// ============================================================
// admin/jadwal.php — Kelola Jadwal Kuliah
// Fitur: Lihat, Tambah, Edit, Hapus jadwal
// Jadwal inilah yang menentukan kapan tombol absen mahasiswa aktif
// (via fungsi statusJamJadwal() di functions.php)
// ============================================================
require_once 'includes/init.php';

$pageTitle = 'Jadwal Kuliah';
$errors    = [];
$editData  = null;

// ----------------------------------------------------------------
// AKSI POST
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    // ---- Validasi field jadwal (shared Tambah & Edit) ----
    $id_kelas   = (int) ($_POST['id_kelas']   ?? 0);
    $id_matkul  = (int) ($_POST['id_matkul']  ?? 0);
    $id_dosen   = (int) ($_POST['id_dosen']   ?? 0);
    $hari       = trim($_POST['hari']         ?? '');
    $jam_mulai  = trim($_POST['jam_mulai']    ?? '');
    $jam_selesai= trim($_POST['jam_selesai']  ?? '');
    $ruangan    = trim($_POST['ruangan']      ?? '');

    $hariValid = ['Senin','Selasa','Rabu','Kamis','Jumat'];
    if (!$id_kelas)               $errors[] = 'Kelas wajib dipilih';
    if (!$id_matkul)              $errors[] = 'Mata kuliah wajib dipilih';
    if (!$id_dosen)               $errors[] = 'Dosen wajib dipilih';
    if (!in_array($hari,$hariValid)) $errors[] = 'Hari tidak valid';
    if (!$jam_mulai || !$jam_selesai) $errors[] = 'Jam mulai dan selesai wajib diisi';
    if ($jam_mulai >= $jam_selesai)   $errors[] = 'Jam selesai harus setelah jam mulai';

    if (empty($errors)) {
        if ($aksi === 'tambah') {
            $stmt = $pdo->prepare('
                INSERT INTO jadwal (id_kelas, id_matkul, id_dosen, hari, jam_mulai, jam_selesai, ruangan)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ');
            $stmt->execute([$id_kelas, $id_matkul, $id_dosen, $hari, $jam_mulai, $jam_selesai, $ruangan]);
            $_SESSION['flash'] = ['type'=>'success','message'=>'Jadwal baru berhasil ditambahkan!'];
            header('Location: jadwal.php'); exit;

        } elseif ($aksi === 'edit') {
            $id_jadwal = (int) ($_POST['id_jadwal'] ?? 0);
            $stmt = $pdo->prepare('
                UPDATE jadwal
                   SET id_kelas=?, id_matkul=?, id_dosen=?, hari=?,
                       jam_mulai=?, jam_selesai=?, ruangan=?
                 WHERE id_jadwal=?
            ');
            $stmt->execute([$id_kelas, $id_matkul, $id_dosen, $hari,
                            $jam_mulai, $jam_selesai, $ruangan, $id_jadwal]);
            $_SESSION['flash'] = ['type'=>'success','message'=>'Jadwal berhasil diperbarui!'];
            header('Location: jadwal.php'); exit;
        }
    }

    if ($aksi === 'hapus') {
        $id_jadwal = (int) ($_POST['id_jadwal'] ?? 0);
        if ($id_jadwal) {
            // Hapus presensi terkait lebih dulu
            $pdo->prepare('DELETE FROM presensi WHERE id_jadwal = ?')->execute([$id_jadwal]);
            $pdo->prepare('DELETE FROM jadwal WHERE id_jadwal = ?')->execute([$id_jadwal]);
            $_SESSION['flash'] = ['type'=>'success','message'=>'Jadwal berhasil dihapus.'];
        }
        header('Location: jadwal.php'); exit;
    }
}

// ---- GET: ambil data untuk edit ----
if (isset($_GET['edit'])) {
    $s = $pdo->prepare('SELECT * FROM jadwal WHERE id_jadwal = ? LIMIT 1');
    $s->execute([(int)$_GET['edit']]);
    $editData = $s->fetch();
}

// ---- Filter tampilan ----
$filterKelas = (int) ($_GET['id_kelas'] ?? 0);
$filterHari  = trim($_GET['hari'] ?? '');

// ---- Data master untuk dropdown ----
$daftarKelas  = $pdo->query('SELECT id_kelas, nama_jurusan, nama_kelas FROM kelas_jurusan ORDER BY nama_jurusan,nama_kelas')->fetchAll();
$daftarMatkul = $pdo->query('SELECT id_matkul, nama_matkul, tipe FROM mata_kuliah ORDER BY nama_matkul')->fetchAll();
$daftarDosen  = $pdo->query('SELECT id_dosen, nama_dosen, gelar FROM dosen ORDER BY nama_dosen')->fetchAll();
$hariList     = ['Senin','Selasa','Rabu','Kamis','Jumat'];

// ---- Query jadwal dengan filter ----
$sqlJdwl = '
    SELECT j.id_jadwal, j.hari, j.jam_mulai, j.jam_selesai, j.ruangan,
           kj.nama_jurusan, kj.nama_kelas,
           mk.nama_matkul, mk.tipe,
           d.nama_dosen, d.gelar
      FROM jadwal j
      JOIN kelas_jurusan kj ON j.id_kelas  = kj.id_kelas
      JOIN mata_kuliah   mk ON j.id_matkul = mk.id_matkul
      JOIN dosen         d  ON j.id_dosen  = d.id_dosen
     WHERE 1=1
';
$params = [];
if ($filterKelas) { $sqlJdwl .= ' AND j.id_kelas = ?'; $params[] = $filterKelas; }
if ($filterHari)  { $sqlJdwl .= ' AND j.hari = ?';    $params[] = $filterHari;  }
$sqlJdwl .= ' ORDER BY kj.nama_jurusan, kj.nama_kelas,
    FIELD(j.hari,"Senin","Selasa","Rabu","Kamis","Jumat"), j.jam_mulai';
$stmtJdwl = $pdo->prepare($sqlJdwl);
$stmtJdwl->execute($params);
$listJadwal = $stmtJdwl->fetchAll();

require_once 'includes/layout.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800 tracking-tight">Kelola Jadwal Kuliah</h2>
        <p class="text-xs text-gray-500 mt-0.5">
            Pengaturan jam jadwal menentukan aktif/tidaknya tombol absen mahasiswa
        </p>
    </div>
    <button onclick="document.getElementById('modalTambah').classList.remove('hidden')"
            class="px-4 py-2 bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white text-xs font-bold rounded-xl shadow-sm hover:opacity-95 transition flex items-center gap-2">
        <i class="fas fa-plus text-[11px]"></i> Tambah Jadwal Baru
    </button>
</div>

<?php if (!empty($errors)): ?>
<div class="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 mb-4 text-xs">
    <p class="font-semibold mb-1"><i class="fas fa-exclamation-triangle mr-1"></i>Kesalahan:</p>
    <ul class="list-disc list-inside space-y-0.5 font-medium">
        <?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 mb-5">
    <form method="GET" class="flex flex-col md:flex-row items-end gap-3.5">
        <div class="w-full md:flex-1">
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Filter Kelas</label>
            <select name="id_kelas" class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
                <option value="">Semua Kelas</option>
                <?php foreach ($daftarKelas as $kls): ?>
                <option value="<?php echo $kls['id_kelas']; ?>"
                    <?php echo $filterKelas == $kls['id_kelas'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($kls['nama_jurusan'] . ' – ' . $kls['nama_kelas']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="w-full md:w-48">
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Filter Hari</label>
            <select name="hari" class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
                <option value="">Semua Hari</option>
                <?php foreach ($hariList as $h): ?>
                <option value="<?php echo $h; ?>" <?php echo $filterHari === $h ? 'selected' : ''; ?>>
                    <?php echo $h; ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="flex gap-2 w-full md:w-auto">
            <button type="submit" class="flex-1 md:flex-none px-4 py-2 bg-gray-800 hover:bg-gray-900 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5">
                <i class="fas fa-filter text-[10px]"></i> Saring
            </button>
            <?php if ($filterKelas || $filterHari): ?>
            <a href="jadwal.php" class="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-500 rounded-xl transition text-xs flex items-center justify-center" title="Reset">
                <i class="fas fa-arrows-rotate"></i>
            </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="overflow-x-auto thin-scroll">
        <table class="w-full text-left border-collapse">
            <thead class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white">
                <tr>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Kelas & Jurusan</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Hari</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Waktu Kuliah</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Mata Kuliah</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Tipe</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Dosen Pengampu</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Ruangan</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Status Sekarang</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Manajemen Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 bg-white">
                <?php if (empty($listJadwal)): ?>
                <tr>
                    <td colspan="9" class="px-5 py-12 text-center text-gray-400">
                        <div class="flex flex-col items-center gap-2">
                            <i class="fas fa-calendar-xmark text-3xl mb-1"></i>
                            <p class="text-sm font-medium">Tidak ada jadwal ditemukan</p>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($listJadwal as $j):
                    // Cek status jam saat ini untuk kolom "Status Sekarang"
                    $hariMap = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat'];
                    $hariHariIni = $hariMap[(int)date('N')] ?? '';
                    $isHariIni = ($j['hari'] === $hariHariIni);
                    $jamStatus = $isHariIni ? statusJamJadwal($j['jam_mulai'], $j['jam_selesai']) : 'other';
                    $jamBadge  = match($jamStatus) {
                        'aktif'   => ['bg-green-50 text-green-700 border border-green-100', 'Berlangsung'],
                        'belum'   => ['bg-blue-50 text-blue-600 border border-blue-100',    'Belum Mulai'],
                        'selesai' => ['bg-gray-100 text-gray-500 border border-gray-200/60', 'Selesai'],
                        default   => ['bg-gray-50 text-gray-400 border border-gray-100',    'Bukan Hari Ini'],
                    };
                ?>
                <tr class="hover:bg-gray-50/50 transition-colors">
                    <td class="px-5 py-4 text-xs whitespace-nowrap">
                        <span class="inline-block bg-blue-50 text-blue-700 font-semibold px-2.5 py-1 rounded-lg border border-blue-100/70">
                            <?php echo htmlspecialchars($j['nama_jurusan']); ?>
                        </span>
                        <div class="text-[11px] text-gray-400 font-medium mt-1 pl-0.5">
                            <i class="fas fa-layer-group text-[9px] mr-0.5"></i> Kelas <?php echo htmlspecialchars($j['nama_kelas']); ?>
                        </div>
                    </td>
                    <td class="px-5 py-4 text-sm font-bold text-gray-700 whitespace-nowrap">
                        <?php echo $j['hari']; ?>
                    </td>
                    <td class="px-5 py-4 font-mono text-xs font-bold text-gray-600 whitespace-nowrap">
                        <span class="bg-gray-100 text-gray-700 px-2 py-1 rounded-md border border-gray-200/60">
                            <?php echo fmtJam($j['jam_mulai']); ?> – <?php echo fmtJam($j['jam_selesai']); ?>
                        </span>
                    </td>
                    <td class="px-5 py-4 text-sm font-semibold text-gray-800">
                        <?php echo htmlspecialchars($j['nama_matkul']); ?>
                    </td>
                    <td class="px-5 py-4 text-center whitespace-nowrap">
                        <span class="text-[11px] px-2.5 py-1 rounded-full font-bold shadow-sm border
                            <?php echo $j['tipe'] === 'Praktek' ? 'bg-orange-50 text-orange-600 border-orange-100' : 'bg-indigo-50 text-indigo-600 border-indigo-100'; ?>">
                            <?php echo $j['tipe']; ?>
                        </span>
                    </td>
                    <td class="px-5 py-4 text-xs font-medium text-gray-600">
                        <i class="fas fa-user-tie text-gray-400 mr-1.5"></i><?php echo htmlspecialchars(trim($j['gelar'].' '.$j['nama_dosen'])); ?>
                    </td>
                    <td class="px-5 py-4 text-xs font-mono font-bold text-gray-500 whitespace-nowrap">
                        <span class="bg-amber-50 text-amber-700 border border-amber-100/70 px-2 py-0.5 rounded"><?php echo htmlspecialchars($j['ruangan'] ?: '—'); ?></span>
                    </td>
                    <td class="px-5 py-4 text-center whitespace-nowrap">
                        <span class="text-xs font-bold px-2.5 py-1 rounded-lg <?php echo $jamBadge[0]; ?>">
                            <?php echo $jamBadge[1]; ?>
                        </span>
                    </td>
                    <td class="px-5 py-4 whitespace-nowrap">
                        <div class="flex items-center justify-center gap-2">
                            <a href="jadwal.php?edit=<?php echo $j['id_jadwal']; ?>"
                               class="w-7 h-7 bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center transition shadow-sm"
                               title="Ubah Jadwal">
                                <i class="fas fa-pen text-[11px]"></i>
                            </a>
                            <form method="POST" onsubmit="return confirm('Hapus jadwal ini? Semua presensi terkait juga terhapus.')" class="inline">
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id_jadwal" value="<?php echo $j['id_jadwal']; ?>">
                                <button type="submit"
                                        class="w-7 h-7 bg-red-50 hover:bg-red-100 text-red-500 rounded-lg flex items-center justify-center transition shadow-sm"
                                        title="Hapus Jadwal">
                                    <i class="fas fa-trash-can text-[11px]"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-5 py-3 border-t border-gray-100 bg-gray-50/60 text-[11px] text-gray-400 font-medium">
        Menampilkan total <?php echo count($listJadwal); ?> entri jadwal kuliah di sistem.
    </div>
</div>

<div id="modalTambah" class="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-gray-100 animate-fade-in-up">
        <div class="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gradient-to-br from-[#144A8C] to-[#1F5DAA] text-white">
            <h3 class="font-bold text-sm tracking-wide"><i class="fas fa-calendar-plus mr-1.5"></i> Tambah Jadwal Baru</h3>
            <button onclick="document.getElementById('modalTambah').classList.add('hidden')"
                    class="text-white/70 hover:text-white transition text-sm">
                <i class="fas fa-times text-base"></i>
            </button>
        </div>
        <?php echo buildJadwalForm('tambah', null, $daftarKelas, $daftarMatkul, $daftarDosen, $hariList); ?>
    </div>
</div>

<?php if ($editData): ?>
<div id="modalEdit" class="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-gray-100 animate-fade-in-up">
        <div class="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gradient-to-br from-amber-500 to-amber-600 text-white">
            <h3 class="font-bold text-sm tracking-wide"><i class="fas fa-calendar-day mr-1.5"></i> Ubah Data Informasi Jadwal</h3>
            <a href="jadwal.php" class="text-white/70 hover:text-white transition text-sm">
                <i class="fas fa-times text-base"></i>
            </a>
        </div>
        <?php echo buildJadwalForm('edit', $editData, $daftarKelas, $daftarMatkul, $daftarDosen, $hariList); ?>
    </div>
</div>
<?php endif; ?>

<?php
// ---- Fungsi helper render form jadwal (tambah & edit share form yang sama) ----
function buildJadwalForm(string $aksi, ?array $d, array $kelas, array $matkul, array $dosen, array $hari): string {
    ob_start();
    ?>
    <form method="POST" class="px-6 py-5 space-y-4">
        <input type="hidden" name="aksi" value="<?php echo $aksi; ?>">
        <?php if ($aksi === 'edit' && $d): ?>
        <input type="hidden" name="id_jadwal" value="<?php echo $d['id_jadwal']; ?>">
        <?php endif; ?>

        <div>
            <label class="block text-xs font-semibold text-gray-600 mb-1">Kelas *</label>
            <select name="id_kelas" required class="admin-input">
                <option value="">— Pilih Kelas —</option>
                <?php foreach ($kelas as $k): ?>
                <option value="<?php echo $k['id_kelas']; ?>"
                    <?php echo ($d && $d['id_kelas'] == $k['id_kelas']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($k['nama_jurusan'] . ' – ' . $k['nama_kelas']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="block text-xs font-semibold text-gray-600 mb-1">Mata Kuliah *</label>
            <select name="id_matkul" required class="admin-input">
                <option value="">— Pilih Mata Kuliah —</option>
                <?php foreach ($matkul as $m): ?>
                <option value="<?php echo $m['id_matkul']; ?>"
                    <?php echo ($d && $d['id_matkul'] == $m['id_matkul']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($m['nama_matkul'].' ('.$m['tipe'].')'); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="block text-xs font-semibold text-gray-600 mb-1">Dosen Pengampu *</label>
            <select name="id_dosen" required class="admin-input">
                <option value="">— Pilih Dosen —</option>
                <?php foreach ($dosen as $ds): ?>
                <option value="<?php echo $ds['id_dosen']; ?>"
                    <?php echo ($d && $d['id_dosen'] == $ds['id_dosen']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars(trim($ds['gelar'].' '.$ds['nama_dosen'])); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Hari *</label>
                <select name="hari" required class="admin-input">
                    <?php foreach ($hari as $h): ?>
                    <option value="<?php echo $h; ?>" <?php echo ($d && $d['hari'] === $h) ? 'selected' : ''; ?>>
                        <?php echo $h; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Ruangan</label>
                <input type="text" name="ruangan" value="<?php echo htmlspecialchars($d['ruangan'] ?? ''); ?>"
                       class="admin-input" placeholder="Cth: A1-04">
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Jam Mulai *</label>
                <input type="time" name="jam_mulai" value="<?php echo htmlspecialchars($d['jam_mulai'] ?? ''); ?>"
                       required class="admin-input">
                <p class="text-[10px] text-blue-600 mt-1 font-medium">
                    <i class="fas fa-info-circle"></i>
                    Jam ini menentukan kapan tombol absen aktif
                </p>
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Jam Selesai *</label>
                <input type="time" name="jam_selesai" value="<?php echo htmlspecialchars($d['jam_selesai'] ?? ''); ?>"
                       required class="admin-input">
            </div>
        </div>
        <div class="flex justify-end gap-3 pt-3 border-t border-gray-100">
            <?php if ($aksi === 'edit'): ?>
            <a href="jadwal.php" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition">Batal</a>
            <?php military_cancel: ?>
            <?php else: ?>
            <button type="button" onclick="document.getElementById('modalTambah').classList.add('hidden')"
                    class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition">Batal</button>
            <?php endif; ?>
            <button type="submit" class="px-4 py-2 bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm">
                <i class="fas fa-save"></i> <?php echo $aksi === 'edit' ? 'Perbarui Data' : 'Simpan Jadwal'; ?>
            </button>
        </div>
    </form>
    <?php
    return ob_get_clean();
}

require_once 'includes/layout_footer.php';
?>