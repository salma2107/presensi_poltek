<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Hanya hapus variabel khusus milik admin
unset($_SESSION['id_admin']);
unset($_SESSION['admin_nama']);
unset($_SESSION['admin_username']);
unset($_SESSION['admin_role']);

// Karena file ini ada di dalam folder admin, mundurkan arah redirect ke login utama
header("Location: ../index.php");
exit;