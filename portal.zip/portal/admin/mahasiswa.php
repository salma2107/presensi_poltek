<?php
// ============================================================
// admin/mahasiswa.php — Kelola Data Mahasiswa
// Fitur: Lihat daftar, Tambah, Edit, Hapus, Reset Password
// ============================================================
require_once __DIR__ . '/includes/init.php'; // ADMIN_GUARD sudah otomatis didefinisikan di dalam init.php

$pageTitle = 'Data Mahasiswa';
$errors    = [];
$editData  = null;

// ----------------------------------------------------------------
// AKSI POST: Proses semua operasi CRUD + Reset Password
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    // ---- TAMBAH MAHASISWA ----
    if ($aksi === 'tambah') {
        $nama       = trim($_POST['nama']       ?? '');
        $nim        = trim($_POST['nim']        ?? '');
        $id_kelas   = (int) ($_POST['id_kelas'] ?? 0);
        $email      = trim($_POST['email']      ?? '');
        $no_telepon = trim($_POST['no_telepon'] ?? '');
        $tgl_lahir  = $_POST['tanggal_lahir']   ?? '';
        $thn_masuk  = (int) ($_POST['tahun_masuk'] ?? date('Y'));
        $password   = $_POST['password']        ?? $nim; // Default password = NIM

        if (empty($nama))     $errors[] = 'Nama wajib diisi';
        if (empty($nim))      $errors[] = 'NIM wajib diisi';
        if (!$id_kelas)       $errors[] = 'Kelas wajib dipilih';
        if (strlen($password) < 4) $errors[] = 'Password minimal terdiri dari 4 karakter';

        if (empty($errors)) {
            // Cek keunikan NIM
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM mahasiswa WHERE nim = ?');
            $stmt->execute([$nim]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "NIM '{$nim}' sudah terdaftar dalam sistem";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmtInsert = $pdo->prepare('
                    INSERT INTO mahasiswa (nama, nim, id_kelas, email, no_telepon, tanggal_lahir, tahun_masuk, password)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ');
                $stmtInsert->execute([
                    $nama, $nim, $id_kelas, 
                    empty($email) ? null : $email,
                    empty($no_telepon) ? null : $no_telepon,
                    empty($tgl_lahir) ? null : $tgl_lahir,
                    $thn_masuk, $hashed
                ]);
                setFlash('success', "Mahasiswa bernama '{$nama}' berhasil ditambahkan.");
                header('Location: mahasiswa.php');
                exit;
            }
        }
    }

    // ---- UPDATE MAHASISWA ----
    if ($aksi === 'update') {
        $id_mhs     = (int) ($_POST['id_mahasiswa'] ?? 0);
        $nama       = trim($_POST['nama']           ?? '');
        $nim        = trim($_POST['nim']            ?? '');
        $id_kelas   = (int) ($_POST['id_kelas']     ?? 0);
        $email      = trim($_POST['email']          ?? '');
        $no_telepon = trim($_POST['no_telepon']     ?? '');
        $tgl_lahir  = $_POST['tanggal_lahir']       ?? '';

        if (!$id_mhs)       $errors[] = 'ID Mahasiswa tidak valid';
        if (empty($nama))   $errors[] = 'Nama wajib diisi';
        if (empty($nim))    $errors[] = 'NIM wajib diisi';
        if (!$id_kelas)     $errors[] = 'Kelas wajib dipilih';

        if (empty($errors)) {
            // Cek keunikan NIM kecuali dirinya sendiri
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM mahasiswa WHERE nim = ? AND id_mahasiswa != ?');
            $stmt->execute([$nim, $id_mhs]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "NIM '{$nim}' sudah dipakai mahasiswa lain";
            } else {
                $stmtUp = $pdo->prepare('
                    UPDATE mahasiswa 
                       SET nama = ?, nim = ?, id_kelas = ?, email = ?, no_telepon = ?, tanggal_lahir = ?
                     WHERE id_mahasiswa = ?
                ');
                $stmtUp->execute([
                    $nama, $nim, $id_kelas,
                    empty($email) ? null : $email,
                    empty($no_telepon) ? null : $no_telepon,
                    empty($tgl_lahir) ? null : $tgl_lahir,
                    $id_mhs
                ]);
                setFlash('success', 'Informasi profil mahasiswa berhasil diperbarui.');
                header('Location: mahasiswa.php');
                exit;
            }
        }
    }

    // ---- RESET PASSWORD ----
    if ($aksi === 'reset_password') {
        $id_mhs = (int) ($_POST['id_mahasiswa'] ?? 0);
        if ($id_mhs) {
            // Ambil NIM untuk dijadikan password default bawaan kembali
            $stmtN = $pdo->prepare('SELECT nim, nama FROM mahasiswa WHERE id_mahasiswa = ?');
            $stmtN->execute([$id_mhs]);
            $m = $stmtN->fetch();
            if ($m) {
                $newHash = password_hash($m['nim'], PASSWORD_DEFAULT);
                $stmtReset = $pdo->prepare('UPDATE mahasiswa SET password = ? WHERE id_mahasiswa = ?');
                $stmtReset->execute([$newHash, $id_mhs]);
                setFlash('success', "Password untuk '{$m['nama']}' telah di-reset kembali menjadi NIM.");
            }
        }
        header('Location: mahasiswa.php');
        exit;
    }

    // ---- HAPUS MAHASISWA ----
    if ($aksi === 'hapus') {
        $id_mhs = (int) ($_POST['id_mahasiswa'] ?? 0);
        if ($id_mhs) {
            try {
                $stmtDel = $pdo->prepare('DELETE FROM mahasiswa WHERE id_mahasiswa = ?');
                $stmtDel->execute([$id_mhs]);
                setFlash('success', 'Data mahasiswa berhasil dihapus permanen.');
            } catch (PDOException $e) {
                setFlash('danger', 'Gagal menghapus data. Mahasiswa ini kemungkinan besar sudah memiliki riwayat log kehadiran.');
            }
        }
        header('Location: mahasiswa.php');
        exit;
    }
}

// ----------------------------------------------------------------
// AMBIL DATA GET: Mengaktifkan mode edit & query pencarian/filter
// ----------------------------------------------------------------
if (isset($_GET['edit_id'])) {
    $idEdit = (int) $_GET['edit_id'];
    $stmtE  = $pdo->prepare('SELECT * FROM mahasiswa WHERE id_mahasiswa = ?');
    $stmtE->execute([$idEdit]);
    $editData = $stmtE->fetch();
}

$search = trim($_GET['search'] ?? '');
$filterKelas = (int) ($_GET['id_kelas'] ?? 0);

// Urutan Query SQL Dinamis
$sql = '
    SELECT m.*, kj.nama_jurusan, kj.nama_kelas
      FROM mahasiswa m
      JOIN kelas_jurusan kj ON m.id_kelas = kj.id_kelas
     WHERE 1=1
';
$params = [];

if ($search !== '') {
    $sql .= ' AND (m.nama LIKE ? OR m.nim LIKE ? OR m.email LIKE ?)';
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($filterKelas > 0) {
    $sql .= ' AND m.id_kelas = ?';
    $params[] = $filterKelas;
}

$sql .= ' ORDER BY kj.nama_jurusan ASC, kj.nama_kelas ASC, m.nim ASC';
$stmtList = $pdo->prepare($sql);
$stmtList->execute($params);
$daftarMahasiswa = $stmtList->fetchAll();

// Ambil pelengkap dropdown form
$daftarKelas = $pdo->query('SELECT id_kelas, nama_jurusan, nama_kelas FROM kelas_jurusan ORDER BY nama_jurusan, nama_kelas')->fetchAll();

// Memanggil layout utama panel setelah variabel-variabel siap diproses oleh view
require_once 'includes/layout.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
    <div>
        <h2 class="text-xl font-bold text-gray-800 tracking-tight">Manajemen Data Mahasiswa</h2>
        <p class="text-xs text-gray-500 mt-0.5">Kelola data profil, akun login, kelas, serta reset sandi mahasiswa</p>
    </div>
    <div>
        <?php if (!$editData): ?>
        <button onclick="document.getElementById('modalTambahMhs').classList.remove('hidden')"
                class="px-4 py-2 bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white text-xs font-bold rounded-xl shadow-sm hover:opacity-95 transition flex items-center gap-2">
            <i class="fas fa-user-plus text-[11px]"></i> Tambah Mahasiswa Baru
        </button>
        <?php else: ?>
        <a href="mahasiswa.php" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition flex items-center gap-1.5">
            <i class="fas fa-arrow-left text-[10px]"></i> Kembali ke List
        </a>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($errors)): ?>
<div class="mb-5 p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl space-y-1">
    <p class="font-bold flex items-center gap-1.5 mb-1"><i class="fas fa-triangle-exclamation"></i> Periksa kembali inputan Anda:</p>
    <ul class="list-disc pl-4 space-y-0.5 font-medium">
        <?php foreach ($errors as $err) echo '<li>'.htmlspecialchars($err).'</li>'; ?>
    </ul>
</div>
<?php endif; ?>

<?php adminFlash(); ?>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 mb-5">
    <form method="GET" action="mahasiswa.php" class="flex flex-col md:flex-row items-end gap-3.5">
        <div class="w-full md:flex-1">
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Pencarian Fleksibel</label>
            <div class="relative">
                <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                    <i class="fas fa-magnifying-glass text-xs"></i>
                </span>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>"
                       class="w-full pl-9 pr-4 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-800 placeholder-gray-400 focus:bg-white focus:border-blue-500 focus:outline-none transition"
                       placeholder="Masukkan nama, nim, atau email...">
            </div>
        </div>
        <div class="w-full md:w-56">
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Filter Kelas</label>
            <select name="id_kelas" class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
                <option value="0">-- Semua Kelas --</option>
                <?php foreach ($daftarKelas as $kls): ?>
                <option value="<?php echo $kls['id_kelas']; ?>" <?php echo $filterKelas === (int)$kls['id_kelas'] ? 'selected':''; ?>>
                    <?php echo htmlspecialchars($kls['nama_jurusan'] . ' (' . $kls['nama_kelas'] . ')'); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="flex gap-2 w-full md:w-auto">
            <button type="submit" class="flex-1 md:flex-none px-4 py-2 bg-gray-800 hover:bg-gray-900 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5">
                <i class="fas fa-filter text-[10px]"></i> Saring
            </button>
            <?php if ($search !== '' || $filterKelas > 0): ?>
            <a href="mahasiswa.php" class="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-500 rounded-xl transition text-xs flex items-center justify-center" title="Reset">
                <i class="fas fa-arrows-rotate"></i>
            </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="grid grid-cols-1 gap-6">
    
    <?php if ($editData): ?>
    <div class="bg-white border border-amber-200 rounded-2xl shadow-sm overflow-hidden">
        <div class="bg-gradient-to-br from-amber-500 to-amber-600 p-4 text-white">
            <h3 class="font-bold text-sm flex items-center gap-2"><i class="fas fa-user-pen"></i> Ubah Data Informasi Mahasiswa</h3>
            <p class="text-[11px] text-amber-100 mt-0.5">Mengoreksi profil NIM: <?php echo htmlspecialchars($editData['nim']); ?></p>
        </div>
        <form method="POST" action="mahasiswa.php" class="p-5 space-y-4">
            <input type="hidden" name="aksi" value="update">
            <input type="hidden" name="id_mahasiswa" value="<?php echo $editData['id_mahasiswa']; ?>">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1">Nama Lengkap Mahasiswa</label>
                    <input type="text" name="nama" required value="<?php echo htmlspecialchars($editData['nama']); ?>" class="admin-input">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1">Nomor Induk Mahasiswa (NIM)</label>
                    <input type="text" name="nim" required value="<?php echo htmlspecialchars($editData['nim']); ?>" class="admin-input">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1">Penempatan Kelas & Jurusan</label>
                    <select name="id_kelas" required class="admin-input">
                        <?php foreach ($daftarKelas as $kls): ?>
                        <option value="<?php echo $kls['id_kelas']; ?>" <?php echo $editData['id_kelas'] == $kls['id_kelas'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kls['nama_jurusan'] . ' – ' . $kls['nama_kelas']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1">Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($editData['email'] ?? ''); ?>" class="admin-input">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1">No. Telepon</label>
                    <input type="text" name="no_telepon" value="<?php echo htmlspecialchars($editData['no_telepon'] ?? ''); ?>" class="admin-input">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-600 mb-1">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" value="<?php echo htmlspecialchars($editData['tanggal_lahir'] ?? ''); ?>" class="admin-input">
                </div>
            </div>
            <div class="flex justify-end gap-3 pt-4 border-t border-gray-100">
                <a href="mahasiswa.php" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition">Batal</a>
                <button type="submit" class="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm">
                    <i class="fas fa-save"></i> Perbarui Data
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto thin-scroll">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white">
                    <tr>
                        <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">NIM / Identitas</th>
                        <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Nama Lengkap</th>
                        <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Kelas & Jurusan</th>
                        <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Kontak Penghubung</th>
                        <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Tahun Masuk</th>
                        <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Manajemen Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 bg-white">
                    <?php if (empty($daftarMahasiswa)): ?>
                    <tr>
                        <td colspan="6" class="px-5 py-12 text-center text-gray-400">
                            <div class="flex flex-col items-center gap-2">
                                <i class="fas fa-users-slash text-3xl mb-1"></i>
                                <p class="text-sm font-medium">Tidak ada data mahasiswa terdaftar yang cocok</p>
                            </div>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($daftarMahasiswa as $row): ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="px-5 py-4 font-mono text-xs font-bold text-gray-700 whitespace-nowrap">
                            <span class="bg-gray-100 text-gray-800 px-2 py-1 rounded-md border border-gray-200/60"><?php echo htmlspecialchars($row['nim']); ?></span>
                        </td>
                        <td class="px-5 py-4">
                            <p class="font-semibold text-sm text-gray-800 leading-tight"><?php echo htmlspecialchars($row['nama']); ?></p>
                            <p class="text-[11px] text-gray-400 mt-0.5 flex items-center gap-1">
                                <i class="far fa-calendar-alt text-[10px]"></i> Lahir: <?php echo $row['tanggal_lahir'] ? date('d-m-Y', strtotime($row['tanggal_lahir'])) : '—'; ?>
                            </p>
                        </td>
                        <td class="px-5 py-4 text-xs text-gray-600 leading-tight whitespace-nowrap">
                            <span class="inline-block bg-blue-50 text-blue-700 font-semibold px-2.5 py-1 rounded-lg border border-blue-100/70">
                                <?php echo htmlspecialchars($row['nama_jurusan']); ?>
                            </span>
                            <div class="text-[11px] text-gray-400 font-medium mt-1 pl-0.5">
                                <i class="fas fa-layer-group text-[9px] mr-0.5"></i> Kelas <?php echo htmlspecialchars($row['nama_kelas']); ?>
                            </div>
                        </td>
                        <td class="px-5 py-4 text-xs leading-normal">
                            <p class="text-gray-700 font-medium max-w-[170px] truncate"><i class="far fa-envelope text-gray-400 mr-1"></i><?php echo htmlspecialchars($row['email'] ?? '—'); ?></p>
                            <p class="text-gray-400 text-[11px] font-mono mt-0.5"><i class="fas fa-phone text-[10px] text-gray-300 mr-1"></i><?php echo htmlspecialchars($row['no_telepon'] ?? '—'); ?></p>
                        </td>
                        <td class="px-5 py-4 text-center font-mono text-xs font-semibold text-gray-500 whitespace-nowrap">
                            <?php echo $row['tahun_masuk']; ?>
                        </td>
                        <td class="px-5 py-4 whitespace-nowrap">
                            <div class="flex items-center justify-center gap-2">
                                <a href="mahasiswa.php?edit_id=<?php echo $row['id_mahasiswa']; ?>" 
                                   class="w-7 h-7 bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center transition shadow-sm"
                                   title="Ubah Profil">
                                    <i class="fas fa-pen text-[11px]"></i>
                                </a>

                                <form method="POST" action="mahasiswa.php" onsubmit="return confirm('Reset sandi mahasiswa ini? Sandi default akan diatur kembali sesuai NIM.');" class="inline">
                                    <input type="hidden" name="aksi" value="reset_password">
                                    <input type="hidden" name="id_mahasiswa" value="<?php echo $row['id_mahasiswa']; ?>">
                                    <button type="submit" class="w-7 h-7 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center transition shadow-sm" title="Reset Kata Sandi">
                                        <i class="fas fa-key text-[11px]"></i>
                                    </button>
                                </form>

                                <form method="POST" action="mahasiswa.php" onsubmit="return confirm('Hapus data mahasiswa \'<?php echo addslashes($row['nama']); ?>\' secara permanen?');" class="inline">
                                    <input type="hidden" name="aksi" value="hapus">
                                    <input type="hidden" name="id_mahasiswa" value="<?php echo $row['id_mahasiswa']; ?>">
                                    <button type="submit" class="w-7 h-7 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg flex items-center justify-center transition shadow-sm" title="Hapus Akun">
                                        <i class="fas fa-trash-can text-[11px]"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-5 py-3 bg-gray-50/60 border-t border-gray-100 text-[11px] text-gray-400 font-medium">
            Menampilkan total <?php echo count($daftarMahasiswa); ?> entri mahasiswa terdata di sistem.
        </div>
    </div>
</div>

<div id="modalTambahMhs" class="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 hidden">
    <div class="bg-white w-full max-w-xl rounded-2xl shadow-xl overflow-hidden border border-gray-100 animate-fade-in-up" onclick="event.stopPropagation()">
        <div class="bg-gradient-to-br from-[#144A8C] to-[#1F5DAA] p-4 text-white flex items-center justify-between">
            <h3 class="font-bold text-sm tracking-wide"><i class="fas fa-user-plus mr-1.5"></i> Registrasi Mahasiswa Baru</h3>
            <button onclick="document.getElementById('modalTambahMhs').classList.add('hidden')" class="text-white/70 hover:text-white transition text-sm">
                <i class="fas fa-xmark text-base"></i>
            </button>
        </div>
        <form method="POST" action="mahasiswa.php" class="p-5 space-y-4">
            <input type="hidden" name="aksi" value="tambah">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Nama Lengkap *</label>
                    <input type="text" name="nama" required class="admin-input" placeholder="Contoh: Muhammad Rafli">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">NIM *</label>
                    <input type="text" name="nim" required class="admin-input" placeholder="Contoh: 210401088">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Pilih Kelas *</label>
                    <select name="id_kelas" required class="admin-input">
                        <option value="">-- Pilih Penempatan --</option>
                        <?php foreach ($daftarKelas as $kls): ?>
                        <option value="<?php echo $kls['id_kelas']; ?>">
                            <?php echo htmlspecialchars($kls['nama_jurusan'] . ' – ' . $kls['nama_kelas']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Tahun Masuk (Angkatan)</label>
                    <input type="number" name="tahun_masuk" value="<?php echo date('Y'); ?>" class="admin-input">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Email</label>
                    <input type="email" name="email" class="admin-input" placeholder="alamat@domain.com">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">No. Telepon / WA</label>
                    <input type="text" name="no_telepon" class="admin-input" placeholder="0812xxxxxxxx">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="admin-input">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Kata Sandi Akun</label>
                    <input type="password" name="password" class="admin-input" placeholder="Kosongkan jika ingin default bawaan = NIM">
                </div>
            </div>

            <p class="text-[11px] text-gray-400 font-medium italic">* Menunjukkan baris bidang wajib diinputkan secara lengkap.</p>

            <div class="flex items-center gap-3 pt-3 border-t border-gray-100">
                <button type="button" onclick="document.getElementById('modalTambahMhs').classList.add('hidden')"
                        class="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition text-center">
                    Batal
                </button>
                <button type="submit"
                        class="flex-1 py-2.5 bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] hover:opacity-95 text-white text-xs font-bold rounded-xl transition text-center shadow-md">
                    Simpan Registrasi
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('modalTambahMhs').addEventListener('click', function(e) {
    if (e.target === this) this.classList.add('hidden');
});
</script>

<?php require_once 'includes/layout_footer.php'; ?>