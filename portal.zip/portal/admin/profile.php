<?php
// ============================================================
// admin/profile.php — Profil & Ganti Password Admin
// Fitur:
//   - Tampilkan info akun admin dari session & database
//   - Update nama & email admin
//   - Ganti password dengan verifikasi password_verify() lama
//     lalu hash baru via password_hash()
// ============================================================
require_once 'includes/init.php';

$pageTitle = 'Profil Admin';
$adminData = getAdmin();
$errUpdate = [];
$errPass   = [];

// Ambil data lengkap admin dari DB (session hanya simpan sebagian)
$stmtAdmin = $pdo->prepare('SELECT * FROM admin WHERE id_admin = ? LIMIT 1');
$stmtAdmin->execute([$adminData['id_admin']]);
$adminDB   = $stmtAdmin->fetch();

if (!$adminDB) {
    session_destroy();
    header('Location: ../index.php');
    exit;
}

// ----------------------------------------------------------------
// AKSI POST
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    // ---- UPDATE INFO AKUN (nama & email) ----
    if ($aksi === 'update_info') {
        $nama  = trim($_POST['nama']  ?? '');
        $email = trim($_POST['email'] ?? '');

        if (empty($nama))
            $errUpdate[] = 'Nama wajib diisi.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL))
            $errUpdate[] = 'Format email tidak valid.';

        if (empty($errUpdate)) {
            $stmt = $pdo->prepare('UPDATE admin SET nama = ?, email = ? WHERE id_admin = ?');
            $stmt->execute([$nama, $email, $adminDB['id_admin']]);

            // Sinkronisasi session agar nama di header langsung berubah
            $_SESSION['admin_nama'] = $nama;

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Informasi akun berhasil diperbarui!'];
            header('Location: profile.php');
            exit;
        }
    }

    // ---- GANTI PASSWORD ----
    if ($aksi === 'ganti_password') {
        $passLama   = $_POST['password_lama']   ?? '';
        $passBaru   = $_POST['password_baru']   ?? '';
        $konfirmasi = $_POST['konfirmasi_baru'] ?? '';

        if (empty($passLama))   $errPass[] = 'Password lama wajib diisi.';
        if (empty($passBaru))   $errPass[] = 'Password baru wajib diisi.';
        if (empty($konfirmasi)) $errPass[] = 'Konfirmasi password wajib diisi.';

        if (empty($errPass)) {
            // Verifikasi password lama — password_verify() aman terhadap timing attack
            if (!password_verify($passLama, $adminDB['password'])) {
                $errPass[] = 'Password lama tidak sesuai.';
            } elseif (strlen($passBaru) < 6) {
                $errPass[] = 'Password baru minimal 6 karakter.';
            } elseif ($passBaru !== $konfirmasi) {
                $errPass[] = 'Konfirmasi password tidak cocok.';
            } elseif (password_verify($passBaru, $adminDB['password'])) {
                $errPass[] = 'Password baru tidak boleh sama dengan password lama.';
            } else {
                // Hash password baru dengan bcrypt
                // password_hash() generate salt unik otomatis setiap kali dipanggil
                $hashBaru = password_hash($passBaru, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare('UPDATE admin SET password = ? WHERE id_admin = ?');
                $stmt->execute([$hashBaru, $adminDB['id_admin']]);

                $_SESSION['flash'] = [
                    'type'    => 'success',
                    'message' => 'Password berhasil diubah! Gunakan password baru untuk login berikutnya.'
                ];
                header('Location: profile.php');
                exit;
            }
        }
    }
}

// Re-fetch setelah update supaya form terisi data terbaru
$stmtAdmin->execute([$adminData['id_admin']]);
$adminDB = $stmtAdmin->fetch();

// Statistik sistem untuk kartu info
$totalMhs      = $pdo->query('SELECT COUNT(*) FROM mahasiswa')->fetchColumn();
$totalJadwal   = $pdo->query('SELECT COUNT(*) FROM jadwal')->fetchColumn();
$totalPresensi = $pdo->query('SELECT COUNT(*) FROM presensi')->fetchColumn();
$totalHariIni  = $pdo->query("SELECT COUNT(*) FROM presensi WHERE tanggal = CURDATE()")->fetchColumn();

require_once 'includes/layout.php';
?>

<div class="max-w-3xl mx-auto space-y-6">

    <!-- ====== KARTU IDENTITAS ADMIN ====== -->
    <div class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div class="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
        <div class="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
        <div class="relative z-10 flex items-center gap-5">
            <!-- Avatar inisial -->
            <div class="w-20 h-20 rounded-2xl bg-white/20 border-2 border-white/30 flex items-center justify-center shrink-0 shadow-lg backdrop-blur-sm">
                <span class="text-3xl font-bold text-white">
                    <?php echo strtoupper(substr($adminDB['nama'], 0, 1)); ?>
                </span>
            </div>
            <div>
                <p class="text-blue-200 text-xs font-medium mb-0.5">Login sebagai</p>
                <h2 class="text-xl font-bold leading-tight"><?php echo htmlspecialchars($adminDB['nama']); ?></h2>
                <p class="text-blue-200 text-sm mt-0.5">@<?php echo htmlspecialchars($adminDB['username']); ?></p>
                <div class="flex items-center gap-2 mt-2">
                    <span class="inline-flex items-center gap-1.5 bg-white/20 text-white text-xs px-3 py-1 rounded-full font-medium">
                        <i class="fas fa-shield-halved text-[10px]"></i>
                        <?php echo ucfirst($adminDB['role']); ?>
                    </span>
                    <span class="inline-flex items-center gap-1.5 bg-white/20 text-white text-xs px-3 py-1 rounded-full font-medium">
                        <i class="fas fa-calendar text-[10px]"></i>
                        Bergabung <?php echo date('Y', strtotime($adminDB['created_at'])); ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- ====== STATISTIK SISTEM ====== -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <?php
        $sysStats = [
            ['label' => 'Mahasiswa',        'val' => $totalMhs,      'icon' => 'fa-users',          'bg' => 'bg-blue-50',   'text' => 'text-blue-600',   'border' => 'border-blue-100'],
            ['label' => 'Total Jadwal',     'val' => $totalJadwal,   'icon' => 'fa-calendar-days',  'bg' => 'bg-purple-50', 'text' => 'text-purple-600', 'border' => 'border-purple-100'],
            ['label' => 'Total Presensi',   'val' => $totalPresensi, 'icon' => 'fa-clipboard-list', 'bg' => 'bg-green-50',  'text' => 'text-green-600',  'border' => 'border-green-100'],
            ['label' => 'Presensi Hari Ini','val' => $totalHariIni,  'icon' => 'fa-bolt',           'bg' => 'bg-amber-50',  'text' => 'text-amber-600',  'border' => 'border-amber-100'],
        ];
        foreach ($sysStats as $s):
        ?>
        <div class="bg-white rounded-xl border <?php echo $s['border']; ?> p-4 flex items-center gap-3 shadow-sm">
            <div class="w-10 h-10 rounded-xl <?php echo $s['bg']; ?> flex items-center justify-center shrink-0">
                <i class="fas <?php echo $s['icon']; ?> <?php echo $s['text']; ?>"></i>
            </div>
            <div>
                <p class="text-xl font-bold text-gray-800"><?php echo $s['val']; ?></p>
                <p class="text-xs text-gray-500"><?php echo $s['label']; ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ====== GRID DUA KOLOM: INFO + PASSWORD ====== -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

        <!-- ---- KARTU UPDATE INFORMASI AKUN ---- -->
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
                <div class="w-9 h-9 bg-blue-50 rounded-xl flex items-center justify-center">
                    <i class="fas fa-user-pen text-blue-600"></i>
                </div>
                <div>
                    <h3 class="font-bold text-gray-800 text-sm">Informasi Akun</h3>
                    <p class="text-[11px] text-gray-400">Perbarui nama dan email admin</p>
                </div>
            </div>

            <?php if (!empty($errUpdate)): ?>
            <div class="mx-5 mt-4 bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm">
                <p class="font-semibold mb-1"><i class="fas fa-exclamation-circle mr-1"></i>Kesalahan:</p>
                <ul class="list-disc list-inside space-y-0.5 text-xs">
                    <?php foreach ($errUpdate as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <form method="POST" class="px-5 py-5 space-y-4">
                <input type="hidden" name="aksi" value="update_info">

                <!-- Username readonly -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Username</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-at text-gray-300 text-sm"></i>
                        </div>
                        <input type="text" value="<?php echo htmlspecialchars($adminDB['username']); ?>"
                               readonly
                               class="w-full pl-9 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-400 cursor-not-allowed">
                    </div>
                    <p class="text-[10px] text-gray-400 mt-1"><i class="fas fa-lock text-[9px]"></i> Username tidak dapat diubah</p>
                </div>

                <!-- Nama -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                        Nama Lengkap <span class="text-red-400">*</span>
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-user text-gray-400 text-sm"></i>
                        </div>
                        <input type="text" name="nama"
                               value="<?php echo htmlspecialchars($adminDB['nama']); ?>"
                               required
                               class="admin-input pl-9 <?php echo !empty($errUpdate) ? 'border-red-300' : ''; ?>">
                    </div>
                </div>

                <!-- Email -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                        Email <span class="text-red-400">*</span>
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400 text-sm"></i>
                        </div>
                        <input type="email" name="email"
                               value="<?php echo htmlspecialchars($adminDB['email']); ?>"
                               required
                               class="admin-input pl-9 <?php echo !empty($errUpdate) ? 'border-red-300' : ''; ?>">
                    </div>
                </div>

                <button type="submit" class="admin-btn-primary w-full justify-center py-2.5">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
            </form>
        </div>

        <!-- ---- KARTU GANTI PASSWORD ---- -->
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
                <div class="w-9 h-9 bg-red-50 rounded-xl flex items-center justify-center">
                    <i class="fas fa-key text-red-500"></i>
                </div>
                <div>
                    <h3 class="font-bold text-gray-800 text-sm">Ganti Password</h3>
                    <p class="text-[11px] text-gray-400">Verifikasi password lama terlebih dahulu</p>
                </div>
            </div>

            <?php if (!empty($errPass)): ?>
            <div class="mx-5 mt-4 bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm">
                <p class="font-semibold mb-1"><i class="fas fa-exclamation-circle mr-1"></i>Kesalahan:</p>
                <ul class="list-disc list-inside space-y-0.5 text-xs">
                    <?php foreach ($errPass as $e): ?>
                    <li><?php echo htmlspecialchars($e); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <form method="POST" class="px-5 py-5 space-y-4">
                <input type="hidden" name="aksi" value="ganti_password">

                <!-- Password lama -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                        Password Lama <span class="text-red-400">*</span>
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400 text-sm"></i>
                        </div>
                        <input type="password" name="password_lama" id="passLama"
                               placeholder="Masukkan password saat ini" required
                               autocomplete="current-password"
                               class="admin-input pl-9 pr-10 <?php echo !empty($errPass) ? 'border-red-300' : ''; ?>">
                        <button type="button" onclick="togglePass('passLama','eyeLama')"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye text-sm" id="eyeLama"></i>
                        </button>
                    </div>
                </div>

                <!-- Divider -->
                <div class="flex items-center gap-2 py-1">
                    <div class="flex-1 h-px bg-gray-100"></div>
                    <span class="text-[10px] text-gray-400 font-semibold uppercase tracking-wide">Password Baru</span>
                    <div class="flex-1 h-px bg-gray-100"></div>
                </div>

                <!-- Password baru -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                        Password Baru <span class="text-red-400">*</span>
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock-open text-gray-400 text-sm"></i>
                        </div>
                        <input type="password" name="password_baru" id="passBaru"
                               placeholder="Minimal 6 karakter" required
                               autocomplete="new-password"
                               oninput="cekKekuatan(this.value)"
                               class="admin-input pl-9 pr-10">
                        <button type="button" onclick="togglePass('passBaru','eyeBaru')"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye text-sm" id="eyeBaru"></i>
                        </button>
                    </div>
                    <!-- Indikator kekuatan password -->
                    <div class="mt-2 space-y-1 hidden" id="strengthBox">
                        <div class="flex gap-1">
                            <div class="h-1.5 flex-1 rounded-full bg-gray-200" id="bar1"></div>
                            <div class="h-1.5 flex-1 rounded-full bg-gray-200" id="bar2"></div>
                            <div class="h-1.5 flex-1 rounded-full bg-gray-200" id="bar3"></div>
                            <div class="h-1.5 flex-1 rounded-full bg-gray-200" id="bar4"></div>
                        </div>
                        <p class="text-[10px] font-medium" id="strengthLabel"></p>
                    </div>
                </div>

                <!-- Konfirmasi password baru -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                        Konfirmasi Password <span class="text-red-400">*</span>
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400 text-sm"></i>
                        </div>
                        <input type="password" name="konfirmasi_baru" id="passKonfirm"
                               placeholder="Ulangi password baru" required
                               autocomplete="new-password"
                               oninput="cekKonfirmasi()"
                               class="admin-input pl-9 pr-10">
                        <button type="button" onclick="togglePass('passKonfirm','eyeKonfirm')"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye text-sm" id="eyeKonfirm"></i>
                        </button>
                    </div>
                    <p class="text-[11px] mt-1 hidden" id="matchMsg"></p>
                </div>

                <!-- Syarat password -->
                <div class="bg-gray-50 rounded-xl p-3 space-y-1.5">
                    <p class="text-[10px] text-gray-500 font-semibold uppercase tracking-wide mb-2">Syarat Password</p>
                    <?php foreach ([
                        ['req1', 'Minimal 6 karakter'],
                        ['req2', 'Mengandung huruf besar (A–Z)'],
                        ['req3', 'Mengandung angka (0–9)'],
                    ] as [$rid, $rtxt]): ?>
                    <div class="flex items-center gap-2">
                        <i class="fas fa-circle text-gray-300 text-[8px]" id="<?php echo $rid; ?>Icon"></i>
                        <span class="text-[11px] text-gray-500" id="<?php echo $rid; ?>Text"><?php echo $rtxt; ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>

                <button type="submit" class="admin-btn-danger w-full justify-center py-2.5">
                    <i class="fas fa-key"></i> Ubah Password
                </button>
            </form>
        </div>

    </div><!-- akhir grid dua kolom -->

    <!-- ====== INFORMASI SESI ====== -->
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <div class="flex items-center gap-3 mb-4">
            <div class="w-9 h-9 bg-indigo-50 rounded-xl flex items-center justify-center">
                <i class="fas fa-circle-info text-indigo-600"></i>
            </div>
            <h3 class="font-bold text-gray-800 text-sm">Informasi Sesi & Sistem</h3>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <?php
            $infoItems = [
                ['fa-user',         'Username',       $adminDB['username']],
                ['fa-envelope',     'Email',          $adminDB['email'] ?: '—'],
                ['fa-shield-halved','Role',           ucfirst($adminDB['role'])],
                ['fa-calendar-plus','Akun Dibuat',   formatTanggalIndo(date('Y-m-d', strtotime($adminDB['created_at'])))],
                ['fa-clock',        'Waktu Server',   date('H:i:s') . ' WIB'],
                ['fa-server',       'PHP Version',    phpversion()],
            ];
            foreach ($infoItems as [$icon, $label, $val]):
            ?>
            <div class="flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
                <div class="w-8 h-8 rounded-lg bg-white border border-gray-200 flex items-center justify-center shrink-0 shadow-sm">
                    <i class="fas <?php echo $icon; ?> text-gray-500 text-xs"></i>
                </div>
                <div>
                    <p class="text-[10px] text-gray-400 uppercase tracking-wide font-medium"><?php echo $label; ?></p>
                    <p class="text-sm font-semibold text-gray-700 mt-0.5"><?php echo htmlspecialchars($val); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ====== TOMBOL LOGOUT ====== -->
    <a href="../logout.php"
       onclick="return confirm('Yakin ingin keluar dari sesi admin?')"
       class="flex items-center justify-center gap-2 w-full bg-red-50 hover:bg-red-100 border border-red-200
              text-red-600 font-semibold py-3.5 rounded-2xl text-sm transition-all shadow-sm hover:shadow-md">
        <i class="fas fa-sign-out-alt"></i> Keluar / Logout
    </a>

</div><!-- akhir max-w-3xl -->

<!-- ============================================================
     JAVASCRIPT
============================================================ -->
<script>
// ---- Toggle visibilitas password ----
function togglePass(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

// ---- Indikator kekuatan password ----
function cekKekuatan(val) {
    const box = document.getElementById('strengthBox');
    if (!val) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden');

    const checks = {
        len:   val.length >= 6,
        upper: /[A-Z]/.test(val),
        num:   /[0-9]/.test(val),
        spec:  /[^A-Za-z0-9]/.test(val),
    };

    // Update centang syarat
    setReq('req1', checks.len);
    setReq('req2', checks.upper);
    setReq('req3', checks.num);

    const score  = Object.values(checks).filter(Boolean).length;
    const levels = [
        { color: 'bg-red-400',    label: 'Lemah',   textCls: 'text-red-500'    },
        { color: 'bg-orange-400', label: 'Cukup',   textCls: 'text-orange-500' },
        { color: 'bg-yellow-400', label: 'Sedang',  textCls: 'text-yellow-600' },
        { color: 'bg-green-500',  label: 'Kuat',    textCls: 'text-green-600'  },
    ];

    ['bar1','bar2','bar3','bar4'].forEach((id, i) => {
        const el = document.getElementById(id);
        el.className = 'h-1.5 flex-1 rounded-full ' + (i < score ? levels[score-1].color : 'bg-gray-200');
    });

    const lbl = document.getElementById('strengthLabel');
    lbl.textContent = 'Kekuatan: ' + levels[score-1].label;
    lbl.className   = 'text-[10px] font-medium ' + levels[score-1].textCls;
}

function setReq(id, ok) {
    const icon = document.getElementById(id + 'Icon');
    const text = document.getElementById(id + 'Text');
    if (ok) {
        icon.className = 'fas fa-circle-check text-green-500 text-[10px]';
        text.className = 'text-[11px] text-green-600';
    } else {
        icon.className = 'fas fa-circle text-gray-300 text-[8px]';
        text.className = 'text-[11px] text-gray-500';
    }
}

// ---- Cek kecocokan konfirmasi password ----
function cekKonfirmasi() {
    const baru    = document.getElementById('passBaru').value;
    const konfirm = document.getElementById('passKonfirm').value;
    const msg     = document.getElementById('matchMsg');

    if (!konfirm) { msg.classList.add('hidden'); return; }
    msg.classList.remove('hidden');

    if (baru === konfirm) {
        msg.textContent = '✓ Password cocok';
        msg.className   = 'text-[11px] mt-1 text-green-600 font-medium';
    } else {
        msg.textContent = '✗ Password tidak cocok';
        msg.className   = 'text-[11px] mt-1 text-red-500 font-medium';
    }
}
</script>

<?php require_once 'includes/layout_footer.php'; ?>