<?php
// ============================================================
// admin/rekap.php — Rekap Presensi Seluruh Mahasiswa
// ============================================================
require_once __DIR__ . '/includes/init.php';
cekLoginAdmin();

// PEMICU OTOMATIS: Memastikan data yang ditarik ke tabel rekap sudah mencakup 
// status Alpa otomatis bagi mahasiswa yang jam kuliahnya sudah kedaluwarsa/lewat.
if (function_exists('periksaAlpaOtomatis')) {
    periksaAlpaOtomatis($pdo);
}

// --- DEFINISI AMAN: tglIndo hanya jika belum ada ---
if (!function_exists('tglIndo')) {
    function tglIndo($tanggal) {
        if (empty($tanggal) || $tanggal == '0000-00-00') return '-';
        $bulan = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        $pecahkan = explode('-', $tanggal);
        return $pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
    }
}

$pageTitle = 'Rekap Presensi';

// ----------------------------------------------------------------
// AKSI: Edit status presensi
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi_edit'])) {
    $id_presensi = (int) ($_POST['id_presensi']     ?? 0);
    $status_baru = trim($_POST['status_kehadiran']   ?? '');
    $keterangan  = trim($_POST['keterangan']         ?? '');

    $statusValid = ['Hadir','Izin','Sakit','Alpa'];

    if ($id_presensi && in_array($status_baru, $statusValid)) {
        $stmt = $pdo->prepare('
            UPDATE presensi
               SET status_kehadiran = ?,
                   keterangan       = ?,
                   waktu_pencatatan = waktu_pencatatan
             WHERE id_presensi = ?
        ');
        $stmt->execute([$status_baru, $keterangan, $id_presensi]);
        $_SESSION['success'] = 'Status kehadiran berhasil diperbarui oleh administrator.';
    } else {
        $_SESSION['error'] = 'Gagal memperbarui status. Parameter tidak valid.';
    }
    header('Location: rekap.php');
    exit;
}

// ----------------------------------------------------------------
// AMBIL DATA PILIHAN FILTER
// ----------------------------------------------------------------
$daftarKelas = $pdo->query('SELECT id_kelas, nama_jurusan, nama_kelas FROM kelas_jurusan ORDER BY nama_jurusan, nama_kelas')->fetchAll();
$daftarMatkul = $pdo->query('SELECT id_matkul, nama_matkul FROM mata_kuliah ORDER BY nama_matkul')->fetchAll();

// ----------------------------------------------------------------
// LOGIKA AJAX
// ----------------------------------------------------------------
if (isset($_GET['ajax_fetch'])) {
    header('Content-Type: application/json');

    $q        = trim($_GET['q'] ?? '');
    $id_kelas  = (int) ($_GET['id_kelas'] ?? 0);
    $id_matkul = (int) ($_GET['id_matkul'] ?? 0);
    $status    = trim($_GET['status'] ?? '');
    $tgl_mulai = trim($_GET['tgl_mulai'] ?? '');
    $tgl_akhir = trim($_GET['tgl_akhir'] ?? '');

    $actualWhere  = ' WHERE 1=1';
    $paramsActual = [];

    if ($q !== '') {
        $actualWhere .= ' AND (m.nama LIKE ? OR m.nim LIKE ?)';
        $paramsActual[] = "%$q%";
        $paramsActual[] = "%$q%";
    }
    if ($id_kelas > 0) {
        $actualWhere .= ' AND m.id_kelas = ?';
        $paramsActual[] = $id_kelas;
    }
    if ($id_matkul > 0) {
        $actualWhere .= ' AND j.id_matkul = ?';
        $paramsActual[] = $id_matkul;
    }
    if ($status !== '') {
        $actualWhere .= ' AND p.status_kehadiran = ?';
        $paramsActual[] = $status;
    }
    if ($tgl_mulai !== '') {
        $actualWhere .= ' AND p.tanggal >= ?';
        $paramsActual[] = $tgl_mulai;
    }
    if ($tgl_akhir !== '') {
        $actualWhere .= ' AND p.tanggal <= ?';
        $paramsActual[] = $tgl_akhir;
    }

    $sql = '
        SELECT
            p.id_presensi,
            p.tanggal,
            p.waktu_pencatatan,
            p.status_kehadiran,
            p.keterangan,
            m.nama AS nama_mahasiswa,
            m.nim,
            kj.nama_jurusan,
            kj.nama_kelas,
            mk.nama_matkul
          FROM presensi p
          JOIN mahasiswa    m  ON p.id_mahasiswa = m.id_mahasiswa
          JOIN jadwal       j  ON p.id_jadwal    = j.id_jadwal
          JOIN mata_kuliah  mk ON j.id_matkul    = mk.id_matkul
          JOIN kelas_jurusan kj ON m.id_kelas   = kj.id_kelas' . $actualWhere . '
         ORDER BY p.tanggal DESC, p.waktu_pencatatan DESC';

    $params = $paramsActual;

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();

        $dataResponse = [];
        foreach ($results as $r) {
            $dataResponse[] = [
                'id'         => (int)$r['id_presensi'],
                'tanggal'    => tglIndo($r['tanggal']),
                'waktu'      => date('H:i', strtotime($r['waktu_pencatatan'])),
                'nama'       => $r['nama_mahasiswa'],
                'nim'        => $r['nim'],
                'kelas'      => $r['nama_jurusan'] . ' (' . $r['nama_kelas'] . ')',
                'matkul'     => $r['nama_matkul'],
                'status'     => $r['status_kehadiran'],
                'keterangan' => $r['keterangan']
            ];
        }

        echo json_encode(['status' => 'success', 'data' => $dataResponse]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal mengambil log rekap database.']);
    }
    exit;
}

// ----------------------------------------------------------------
// DEFAULT DATA (server-side render)
// ----------------------------------------------------------------
$hariMap   = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu',7=>'Minggu'];
$hariStr   = $hariMap[(int)date('N')] ?? 'Senin';

$stmtDef = $pdo->prepare('
    SELECT
        p.id_presensi,
        p.tanggal,
        p.waktu_pencatatan,
        p.status_kehadiran,
        p.keterangan,
        m.nama AS nama_mahasiswa,
        m.nim,
        kj.nama_jurusan,
        kj.nama_kelas,
        mk.nama_matkul
      FROM presensi p
      JOIN mahasiswa    m  ON p.id_mahasiswa = m.id_mahasiswa
      JOIN jadwal       j  ON p.id_jadwal    = j.id_jadwal
      JOIN mata_kuliah  mk ON j.id_matkul    = mk.id_matkul
      JOIN kelas_jurusan kj ON m.id_kelas   = kj.id_kelas
     ORDER BY p.tanggal DESC, p.waktu_pencatatan DESC
     LIMIT 200
');
$stmtDef->execute();
$rekapDefault = $stmtDef->fetchAll();

// ----------------------------------------------------------------
// STATISTIK
// ----------------------------------------------------------------
$statRekap = ['total' => 0, 'Hadir' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0];

$stmtStat = $pdo->query('SELECT status_kehadiran, COUNT(*) as jumlah FROM presensi GROUP BY status_kehadiran');
$totalSemua = 0;
while ($row = $stmtStat->fetch()) {
    $status = $row['status_kehadiran'];
    $jumlah = (int)$row['jumlah'];
    if (array_key_exists($status, $statRekap)) {
        $statRekap[$status] = $jumlah;
    }
    $totalSemua += $jumlah;
}
$statRekap['total'] = $totalSemua;

// ----------------------------------------------------------------
// HAPUS define ADMIN_GUARD karena sudah ada di init.php
// ----------------------------------------------------------------
require_once 'includes/layout.php';
?>

<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
    <div>
        <h2 class="text-lg font-bold text-gray-800">Rekap Presensi Mahasiswa</h2>
        <p class="text-sm text-gray-500">Filter, cari, dan edit status kehadiran secara manual</p>
    </div>
</div>

<div class="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5" id="statGrid">
    <?php
    $statCards = [
        ['label'=>'Total',  'key'=>'total',  'color'=>'bg-indigo-50 text-indigo-700 border-indigo-100'],
        ['label'=>'Hadir',  'key'=>'Hadir',  'color'=>'bg-green-50 text-green-700 border-green-100'],
        ['label'=>'Izin',   'key'=>'Izin',   'color'=>'bg-blue-50 text-blue-700 border-blue-100'],
        ['label'=>'Sakit',  'key'=>'Sakit',  'color'=>'bg-amber-50 text-amber-700 border-amber-100'],
        ['label'=>'Alpa',   'key'=>'Alpa',   'color'=>'bg-red-50 text-red-700 border-red-100'],
    ];
    foreach ($statCards as $sc): ?>
    <div class="rounded-xl border <?php echo $sc['color']; ?> p-3 text-center">
        <p class="text-2xl font-bold stat-val" data-key="<?php echo $sc['key']; ?>">
            <?php echo $statRekap[$sc['key']] ?? 0; ?>
        </p>
        <p class="text-xs font-medium mt-0.5"><?php echo $sc['label']; ?></p>
    </div>
    <?php endforeach; ?>
</div>

<?php if (isset($_SESSION['success'])): ?>
    <div class="mb-5 p-4 bg-green-50 border border-green-200 text-green-700 text-sm rounded-xl flex items-center gap-2">
        <i class="fas fa-circle-check text-base"></i>
        <p><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
    </div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div class="mb-5 p-4 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-2">
        <i class="fas fa-triangle-exclamation text-base"></i>
        <p><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    </div>
<?php endif; ?>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 mb-6">
    <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wide mb-4 flex items-center gap-2">
        <i class="fas fa-filter text-blue-600"></i> Penyaringan Data & Pencarian Log
    </h2>
    <form id="filterForm" onsubmit="event.preventDefault(); memuatDataPresensi();" class="space-y-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Nama / NIM Mahasiswa</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                        <i class="fas fa-magnifying-glass text-xs"></i>
                    </span>
                    <input type="text" id="filterQuery" oninput="memuatDataPresensi()"
                           class="w-full pl-9 pr-4 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-800 placeholder-gray-400 focus:bg-white focus:border-blue-500 focus:outline-none transition"
                           placeholder="Cari kata kunci nama/nim...">
                </div>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Filter Kelas</label>
                <select id="filterKelas" onchange="memuatDataPresensi()"
                        class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
                    <option value="0">-- Semua Kelas --</option>
                    <?php foreach ($daftarKelas as $kls): ?>
                        <option value="<?php echo $kls['id_kelas']; ?>">
                            <?php echo htmlspecialchars($kls['nama_jurusan'] . ' - ' . $kls['nama_kelas']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Mata Kuliah</label>
                <select id="filterMatkul" onchange="memuatDataPresensi()"
                        class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
                    <option value="0">-- Semua Mata Kuliah --</option>
                    <?php foreach ($daftarMatkul as $mk): ?>
                        <option value="<?php echo $mk['id_matkul']; ?>">
                            <?php echo htmlspecialchars($mk['nama_matkul']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Status Hadir</label>
                <select id="filterStatus" onchange="memuatDataPresensi()"
                        class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
                    <option value="">-- Semua Status --</option>
                    <option value="Hadir">Hadir</option>
                    <option value="Izin">Izin</option>
                    <option value="Sakit">Sakit</option>
                    <option value="Alpa">Alpa</option>
                </select>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Dari Tanggal</label>
                <input type="date" id="filterTglMulai" onchange="memuatDataPresensi()"
                       class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5 ml-0.5">Sampai Tanggal</label>
                <input type="date" id="filterTglAkhir" onchange="memuatDataPresensi()"
                       class="w-full px-3 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-700 focus:bg-white focus:border-blue-500 focus:outline-none transition">
            </div>
        </div>

        <div class="flex justify-end pt-2">
            <button type="button" onclick="resetFormFilter()"
                    class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition flex items-center gap-1.5">
                <i class="fas fa-arrows-rotate text-[10px]"></i> Bersihkan Filter
            </button>
        </div>
    </form>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="overflow-x-auto thin-scroll">
        <table class="w-full text-left border-collapse">
            <thead class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] text-white">
                <tr>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Tanggal & Waktu</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Nama / NIM</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Kelas</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Mata Kuliah</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Status</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider">Keterangan</th>
                    <th class="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 bg-white" id="rekapTbody">
                <?php if (empty($rekapDefault)): ?>
                    <tr>
                        <td colspan="7" class="px-5 py-10 text-center text-gray-400">
                            <div class="flex flex-col items-center gap-2">
                                <i class="fas fa-folder-open text-3xl mb-1"></i>
                                <p class="text-sm font-medium">Belum ada rekaman data presensi dalam sistem</p>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rekapDefault as $r):
                        $sc = match($r['status_kehadiran']) {
                            'Hadir' => 'bg-green-100 text-green-700',
                            'Izin'  => 'bg-blue-100 text-blue-700',
                            'Sakit' => 'bg-yellow-100 text-yellow-700',
                            default => 'bg-red-100 text-red-700',
                        };
                        
                        $packetEdit = json_encode([
                            'id'       => $r['id_presensi'],
                            'nama'     => $r['nama_mahasiswa'],
                            'matkul'   => $r['nama_matkul'],
                            'tanggal'  => tglIndo($r['tanggal']) . ' - ' . date('H:i', strtotime($r['waktu_pencatatan'])),
                            'status'   => $r['status_kehadiran'],
                            'keterangan'=> $r['keterangan']
                        ], JSON_HEX_APOS | JSON_HEX_QUOT);
                    ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="px-5 py-4 font-mono text-xs text-gray-500 whitespace-nowrap leading-tight">
                            <span class="font-semibold text-gray-700"><?php echo tglIndo($r['tanggal']); ?></span><br>
                            <span class="text-[11px] text-gray-400"><i class="far fa-clock mr-1 text-[10px]"></i><?php echo date('H:i', strtotime($r['waktu_pencatatan'])); ?> WIB</span>
                        </td>
                        <td class="px-5 py-4">
                            <p class="font-semibold text-sm text-gray-800 leading-tight"><?php echo htmlspecialchars($r['nama_mahasiswa']); ?></p>
                            <p class="text-[11px] text-gray-400 mt-0.5 font-mono"><?php echo htmlspecialchars($r['nim']); ?></p>
                        </td>
                        <td class="px-5 py-4 text-xs text-gray-600 leading-tight">
                            <?php echo htmlspecialchars($r['nama_jurusan']); ?><br>
                            <span class="text-[11px] text-gray-400 font-medium">Kelas <?php echo htmlspecialchars($r['nama_kelas']); ?></span>
                        </td>
                        <td class="px-5 py-4 text-xs font-semibold text-gray-700 leading-normal max-w-[180px] truncate">
                            <?php echo htmlspecialchars($r['nama_matkul']); ?>
                        </td>
                        <td class="px-5 py-4 text-center whitespace-nowrap">
                            <span class="<?php echo $sc; ?> text-xs font-semibold px-2.5 py-1 rounded-lg">
                                <?php echo $r['status_kehadiran']; ?>
                            </span>
                        </td>
                        <td class="px-5 py-4 text-xs text-gray-500 max-w-[140px] truncate">
                            <?php echo htmlspecialchars($r['keterangan'] ?? '—'); ?>
                        </td>
                        <td class="px-5 py-4 text-center">
                            <button onclick='bukaModalEdit(<?php echo $packetEdit; ?>)'
                                    class="w-8 h-8 bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center transition mx-auto shadow-sm">
                                <i class="fas fa-pen-to-square text-xs"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div id="rekapCounterBar" class="px-5 py-3 bg-gray-50/60 border-t border-gray-100 text-[11px] text-gray-400 font-medium">
        Menampilkan data log rekapitulasi presensi terdaftar.
    </div>
</div>

<div id="modalEditStatus" class="fixed inset-0 bg-gray-900/40 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 hidden">
    <div class="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden border border-gray-100" onclick="event.stopPropagation()">
        <div class="bg-gradient-to-br from-[#144A8C] to-[#1F5DAA] p-4 text-white flex items-center justify-between">
            <h3 class="font-bold text-sm tracking-wide"><i class="fas fa-user-pen mr-1.5"></i> Koreksi Status Kehadiran</h3>
            <button onclick="tutupModalEdit()" class="text-white/70 hover:text-white transition text-sm">
                <i class="fas fa-xmark text-base"></i>
            </button>
        </div>
        <form action="rekap.php" method="POST" class="p-5 space-y-4">
            <input type="hidden" name="aksi_edit" value="1">
            <input type="hidden" name="id_presensi" id="editIdPresensi">

            <div class="bg-gray-50 rounded-xl p-3.5 border border-gray-100 text-xs space-y-1 text-gray-600">
                <p><strong>Nama:</strong> <span id="editNama" class="text-gray-800 font-semibold"></span></p>
                <p><strong>Mata Kuliah:</strong> <span id="editMatkul"></span></p>
                <p><strong>Waktu:</strong> <span id="editTanggal" class="font-mono"></span></p>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Pilih Status Baru</label>
                <select name="status_kehadiran" id="editStatus" required
                        class="w-full px-3 py-2.5 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-800 focus:bg-white focus:border-blue-500 focus:outline-none transition font-semibold">
                    <option value="Hadir">Hadir</option>
                    <option value="Izin">Izin</option>
                    <option value="Sakit">Sakit</option>
                    <option value="Alpa">Alpa</option>
                </select>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Keterangan Alasan / Catatan</label>
                <textarea name="keterangan" id="editKeterangan" rows="3"
                          class="w-full p-3 text-xs bg-gray-50 border border-gray-200 rounded-xl text-gray-800 placeholder-gray-400 focus:bg-white focus:border-blue-500 focus:outline-none transition resize-none"
                          placeholder="Tulis alasan perubahan..."></textarea>
            </div>

            <div class="flex items-center gap-3 pt-2">
                <button type="button" onclick="tutupModalEdit()"
                        class="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-xl transition text-center">
                    Batal
                </button>
                <button type="submit"
                        class="flex-1 py-2.5 bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] hover:opacity-95 text-white text-xs font-bold rounded-xl transition text-center shadow-md">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function esc(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

async function memuatDataPresensi() {
    const q = document.getElementById('filterQuery').value;
    const kelas = document.getElementById('filterKelas').value;
    const matkul = document.getElementById('filterMatkul').value;
    const status = document.getElementById('filterStatus').value;
    const tglM = document.getElementById('filterTglMulai').value;
    const tglA = document.getElementById('filterTglAkhir').value;

    const queryUrl = `rekap.php?ajax_fetch=1&q=${encodeURIComponent(q)}&id_kelas=${kelas}&id_matkul=${matkul}&status=${status}&tgl_mulai=${tglM}&tgl_akhir=${tglA}`;
    
    try {
        const response = await fetch(queryUrl, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const result = await response.json();

        if (result.status === 'success') {
            renderTabelPresensi(result.data);
        }
    } catch (err) {
        console.error("Gagal melakukan pencarian live data:", err);
    }
}

function renderTabelPresensi(listData) {
    const container = document.getElementById('rekapTbody');
    const counter   = document.getElementById('rekapCounterBar');
    
    if (listData.length === 0) {
        container.innerHTML = `<tr>
            <td colspan="7" class="px-5 py-10 text-center text-gray-400">
                <div class="flex flex-col items-center gap-2">
                    <i class="fas fa-magnifying-glass text-3xl mb-1"></i>
                    <p class="text-sm font-medium">Tidak ditemukan data presensi yang cocok dengan filter</p>
                </div>
            </td>
        </tr>`;
        counter.textContent = "Menampilkan 0 hasil pencarian.";
        return;
    }

    counter.textContent = `Berhasil menemukan ${listData.length} baris log data presensi yang sesuai.`;

    container.innerHTML = listData.map(r => {
        let sc = 'bg-red-100 text-red-700';
        if (r.status === 'Hadir') sc = 'bg-green-100 text-green-700';
        if (r.status === 'Izin')  sc = 'bg-blue-100 text-blue-700';
        if (r.status === 'Sakit') sc = 'bg-yellow-100 text-yellow-700';

        const editData = JSON.stringify(r).replace(/"/g, '&quot;').replace(/'/g, '&#039;');

        return `<tr class="hover:bg-gray-50/50 transition-colors">
            <td class="px-5 py-4 font-mono text-xs text-gray-500 whitespace-nowrap leading-tight">
                <span class="font-semibold text-gray-700">${esc(r.tanggal)}</span><br>
                <span class="text-[11px] text-gray-400"><i class="far fa-clock mr-1 text-[10px]"></i>${esc(r.waktu)} WIB</span>
            </td>
            <td class="px-5 py-4">
                <p class="font-semibold text-sm text-gray-800 leading-tight">${esc(r.nama)}</p>
                <p class="text-[11px] text-gray-400 mt-0.5 font-mono">${esc(r.nim)}</p>
            </td>
            <td class="px-5 py-4 text-xs text-gray-600 leading-tight">
                ${esc(r.kelas)}
            </td>
            <td class="px-5 py-4 text-xs font-semibold text-gray-700 leading-normal max-w-[180px] truncate">
                ${esc(r.matkul)}
            </td>
            <td class="px-5 py-4 text-center whitespace-nowrap">
                <span class="${sc} text-xs font-semibold px-2.5 py-1 rounded-lg">${esc(r.status)}</span>
            </td>
            <td class="px-5 py-4 text-xs text-gray-500 max-w-[140px] truncate">${esc(r.keterangan || '—')}</td>
            <td class="px-5 py-4 text-center">
                <button onclick='bukaModalEdit(${editData})'
                        class="w-8 h-8 bg-amber-50 hover:bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center transition mx-auto shadow-sm">
                    <i class="fas fa-pen-to-square text-xs"></i>
                </button>
            </td>
        </tr>`;
    }).join('');
}

function resetFormFilter() {
    document.getElementById('filterForm').reset();
    document.getElementById('filterQuery').value = '';
    document.getElementById('filterKelas').value = '0';
    document.getElementById('filterMatkul').value = '0';
    document.getElementById('filterStatus').value = '';
    document.getElementById('filterTglMulai').value = '';
    document.getElementById('filterTglAkhir').value = '';
    memuatDataPresensi();
}

function bukaModalEdit(data) {
    document.getElementById('editIdPresensi').value  = data.id;
    document.getElementById('editStatus').value      = data.status;
    document.getElementById('editKeterangan').value  = data.keterangan || '';
    document.getElementById('editNama').textContent  = data.nama;
    document.getElementById('editMatkul').textContent= data.matkul;
    document.getElementById('editTanggal').textContent = data.tanggal;
    document.getElementById('modalEditStatus').classList.remove('hidden');
}

function tutupModalEdit() {
    document.getElementById('modalEditStatus').classList.add('hidden');
}

document.getElementById('modalEditStatus').addEventListener('click', function(e) {
    if (e.target === this) tutupModalEdit();
});
</script>

<?php
require_once 'includes/layout_footer.php';
?>