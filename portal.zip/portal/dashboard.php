<?php
// ============================================================
// DASHBOARD.PHP — Dashboard Utama (Database Version)
// ============================================================
require_once 'koneksi.php';   // PDO + timezone Asia/Jakarta
require_once 'functions.php';

cekLogin();

$dataMahasiswa = getMahasiswa();

// Auto-tandai Alpa untuk kelas yang sudah lewat tapi belum absen
periksaAlpaOtomatis($pdo);

// Ambil jadwal hari ini berdasarkan id_kelas dari session
$jadwalHariIni = getJadwalHariIni($pdo);

// Ambil semua riwayat untuk hitung statistik keseluruhan
$semua = getRiwayatPresensi($pdo);
$stat  = hitungStatistik($semua);

// Nama hari Indonesia
$hariId = [
    'Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu',
    'Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu','Sunday'=>'Minggu'
];
$hariEng  = date('l');
$hariIndo = $hariId[$hariEng] ?? $hariEng;
$hariIni  = $hariIndo . ', ' . date('d') . ' ' . ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'][(int)date('n')] . ' ' . date('Y');

// Tag kategori jurusan
$kategoriTags = [
    ['label' => 'Teknik Mesin',        'warna' => 'bg-blue-500'],
    ['label' => 'Teknik Elektronika',  'warna' => 'bg-red-500'],
    ['label' => 'Teknologi Industri',  'warna' => 'bg-purple-500'],
    ['label' => 'Teknologi Informasi', 'warna' => 'bg-orange-500'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Dashboard - Portal Mahasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @keyframes fadeInUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes progressFill { from{width:0%} to{width:<?php echo $stat['persentase']; ?>%} }
        .animate-fade-in-up { animation:fadeInUp .5s ease-out forwards; }
        .animate-progress   { animation:progressFill 1.2s ease-out forwards; }
        .stat-card   { transition:all .3s ease; }
        .stat-card:hover { transform:translateY(-3px); box-shadow:0 10px 25px -5px rgba(0,0,0,.1); }
        .schedule-card { transition:all .2s ease; }
        .schedule-card:hover { border-color:#3B82F6; background:#F8FAFC; }
        .hide-scrollbar::-webkit-scrollbar { display:none; }
        .hide-scrollbar { -ms-overflow-style:none; scrollbar-width:none; }
        .progress-stripe {
            background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);
            background-size:1rem 1rem;
        }
    </style>
</head>
<body class="bg-gray-50 pb-20 lg:pb-0">

    <?php renderBottomNav('dashboard'); ?>

    <div class="lg:pl-64 min-h-screen w-full">

        <div class="w-full max-w-2xl lg:max-w-none mx-auto lg:mx-0 bg-white min-h-screen shadow-sm">

            <?php renderHeader('PORTAL MAHASISWA', 'Sistem Presensi'); ?>

            <?php renderFlashMessage(); ?>

            <main class="px-4 py-3 space-y-4">

                <div class="animate-fade-in-up" style="animation-delay:.05s;">
                    <div class="flex gap-2 overflow-x-auto hide-scrollbar pb-1">
                        <?php foreach ($kategoriTags as $tag): ?>
                        <span class="<?php echo $tag['warna']; ?> text-white text-[11px] font-semibold px-3 py-1.5 rounded-full whitespace-nowrap shadow-sm">
                            <?php echo $tag['label']; ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="animate-fade-in-up" style="animation-delay:.1s;">
                    <div class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] rounded-2xl p-5 text-white shadow-lg relative overflow-hidden">
                        <div class="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                        <div class="relative z-10">
                            <div class="flex items-start justify-between">
                                <div>
                                    <h2 class="text-lg font-bold">Selamat Datang</h2>
                                    <p class="text-white/90 font-semibold text-base mt-0.5"><?php echo htmlspecialchars($dataMahasiswa['nama']); ?></p>
                                    <p class="text-blue-200 text-xs mt-1">
                                        NIM <?php echo htmlspecialchars($dataMahasiswa['nim']); ?> |
                                        <?php echo htmlspecialchars($dataMahasiswa['nama_jurusan']); ?> <?php echo htmlspecialchars($dataMahasiswa['nama_kelas']); ?>
                                    </p>
                                    <p class="text-blue-300/80 text-[11px] mt-1">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo $hariIni; ?>
                                    </p>
                                </div>
                                <div class="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                                    <i class="fas fa-graduation-cap text-white text-xl"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="animate-fade-in-up" style="animation-delay:.15s;">
                    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                        <div class="stat-card bg-gradient-to-br from-[#144A8C] to-[#1F5DAA] rounded-2xl p-4 text-white shadow-md">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-[11px] text-blue-200 font-medium">Total Presensi</span>
                                <div class="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-calendar-check text-sm"></i>
                                </div>
                            </div>
                            <p class="text-2xl font-bold"><?php echo $stat['total']; ?></p>
                        </div>
                        <div class="stat-card bg-gradient-to-br from-[#22C55E] to-[#16A34A] rounded-2xl p-4 text-white shadow-md">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-[11px] text-green-100 font-medium">Hadir</span>
                                <div class="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-check text-sm"></i>
                                </div>
                            </div>
                            <p class="text-2xl font-bold"><?php echo $stat['hadir']; ?></p>
                        </div>
                        <div class="stat-card bg-gradient-to-br from-[#EF4444] to-[#DC2626] rounded-2xl p-4 text-white shadow-md">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-[11px] text-red-100 font-medium">Alpa</span>
                                <div class="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-times text-sm"></i>
                                </div>
                            </div>
                            <p class="text-2xl font-bold"><?php echo $stat['alpa']; ?></p>
                        </div>
                        <div class="stat-card bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-2xl p-4 text-white shadow-md">
                            <div class="flex items-center justify-between mb-2">
                                <span class="text-[11px] text-yellow-100 font-medium">Izin / Sakit</span>
                                <div class="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-notes-medical text-sm"></i>
                                </div>
                            </div>
                            <p class="text-2xl font-bold"><?php echo $stat['izin'] + $stat['sakit']; ?></p>
                        </div>
                    </div>
                </div>

                <div class="animate-fade-in-up" style="animation-delay:.2s;">
                    <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="font-semibold text-gray-800 text-sm">Persentase Kehadiran</h3>
                            <div class="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center">
                                <i class="fas fa-chart-line text-green-500 text-sm"></i>
                            </div>
                        </div>
                        <div class="flex items-baseline gap-1 mb-3">
                            <span class="text-3xl font-bold text-[#144A8C]"><?php echo $stat['persentase']; ?></span>
                            <span class="text-lg font-semibold text-[#144A8C]">%</span>
                        </div>
                        <div class="relative h-3 bg-gray-100 rounded-full overflow-hidden">
                            <div class="absolute top-0 left-0 h-full bg-gradient-to-r from-[#22C55E] to-[#16A34A] rounded-full animate-progress progress-stripe"
                                 style="width:<?php echo $stat['persentase']; ?>%;"></div>
                        </div>
                        <div class="flex justify-between mt-2">
                            <span class="text-[10px] text-gray-400">0%</span>
                            <span class="text-[10px] text-gray-400">50%</span>
                            <span class="text-[10px] text-gray-400">100%</span>
                        </div>
                    </div>
                </div>

                <div class="animate-fade-in-up" style="animation-delay:.25s;">
                    <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                        <div class="flex items-center justify-between mb-4">
                            <div>
                                <h3 class="font-bold text-gray-800 text-sm">Jadwal Hari Ini</h3>
                                <p class="text-[11px] text-gray-400 mt-0.5"><?php echo $hariIni; ?></p>
                            </div>
                            <div class="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                                <i class="fas fa-calendar-day text-[#3B82F6] text-sm"></i>
                            </div>
                        </div>

                        <?php if (empty($jadwalHariIni)): ?>
                        <div class="text-center py-8 text-gray-400">
                            <i class="fas fa-coffee text-3xl mb-2"></i>
                            <p class="text-sm">Tidak ada jadwal hari ini</p>
                        </div>
                        <?php else: ?>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-3">
                            <?php foreach ($jadwalHariIni as $j):
                                $idJadwal   = (int) $j['id_jadwal'];
                                $jamStatus  = statusJamJadwal($j['jam_mulai'], $j['jam_selesai']);
                                $presensi   = getPresensiHariIni($pdo, $idJadwal);
                                $sudahAbsen = $presensi !== null;

                                if ($sudahAbsen) {
                                    $badgeClass = statusKehadiranClass($presensi['status_kehadiran']);
                                    $badgeLabel = $presensi['status_kehadiran'];
                                } else {
                                    $badgeClass = match($jamStatus) {
                                        'aktif'   => 'bg-green-100 text-green-700',
                                        'selesai' => 'bg-gray-100 text-gray-500',
                                        default   => 'bg-blue-50 text-blue-600',
                                    };
                                    $badgeLabel = match($jamStatus) {
                                        'aktif'   => 'Berlangsung',
                                        'selesai' => 'Selesai',
                                        default   => 'Belum Mulai',
                                    };
                                }
                            ?>
                            <div class="schedule-card block border border-gray-100 rounded-xl p-3.5 bg-gray-50/50 relative overflow-hidden <?php echo $sudahAbsen ? 'opacity-80' : ''; ?>">

                                <?php if ($sudahAbsen): ?>
                                <div class="absolute top-2 right-2 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center z-10 shadow-sm">
                                    <i class="fas fa-check text-white text-[9px]"></i>
                                </div>
                                <?php endif; ?>

                                <div class="flex items-start justify-between gap-3 <?php echo $sudahAbsen ? 'pr-6' : ''; ?>">
                                    <div class="flex-1 min-w-0">
                                        <h4 class="font-semibold text-gray-800 text-sm truncate">
                                            <?php echo htmlspecialchars($j['nama_matkul']); ?>
                                            <span class="text-[10px] font-normal text-gray-400 ml-1">(<?php echo $j['tipe']; ?>)</span>
                                        </h4>
                                        <div class="flex items-center gap-3 mt-1.5 text-[11px] text-gray-500">
                                            <span class="flex items-center gap-1">
                                                <i class="far fa-clock text-[10px]"></i>
                                                <?php echo fmtJam($j['jam_mulai']); ?> – <?php echo fmtJam($j['jam_selesai']); ?>
                                            </span>
                                            <span class="flex items-center gap-1">
                                                <i class="fas fa-door-open text-[10px]"></i>
                                                <?php echo htmlspecialchars($j['ruangan']); ?>
                                            </span>
                                        </div>
                                        <p class="text-[11px] text-gray-400 mt-1 truncate">
                                            <i class="fas fa-chalkboard-teacher text-[10px] mr-1"></i>
                                            <?php echo htmlspecialchars(trim($j['nama_dosen'] . ', ' . $j['gelar'])); ?>
                                        </p>
                                    </div>
                                    <span class="<?php echo $badgeClass; ?> text-[10px] font-semibold px-2.5 py-1 rounded-lg whitespace-nowrap shrink-0">
                                        <?php echo $badgeLabel; ?>
                                    </span>
                                </div>

                                <?php if (!$sudahAbsen && $jamStatus === 'aktif'): ?>
                                <div class="mt-2.5 pt-2.5 border-t border-gray-100/80">
                                    <a href="absensi.php?id=<?php echo $idJadwal; ?>"
                                       class="block w-full text-center bg-gradient-to-r from-[#144A8C] to-[#3B82F6] text-white text-[11px] font-semibold py-2 rounded-lg shadow-sm hover:shadow-md transition-all">
                                        <i class="fas fa-hand-paper mr-1"></i> Isi Presensi Sekarang
                                    </a>
                                </div>
                                <?php elseif (!$sudahAbsen && $jamStatus === 'belum'): ?>
                                <div class="mt-2.5 pt-2.5 border-t border-gray-100/80">
                                    <span class="text-[10px] text-amber-600 font-medium flex items-center gap-1">
                                        <i class="fas fa-info-circle text-[9px]"></i>
                                        Absensi dibuka mulai pukul <?php echo fmtJam($j['jam_mulai']); ?> WIB
                                    </span>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

            </main>
            
        </div> </div> <script>
setTimeout(function(){ location.reload(); }, 60000);
</script>

</body>
</html>