<?php
// ============================================================
// FUNCTIONS.PHP — Helper Functions (Database Version)
// Mendukung dua role: Mahasiswa & Admin
// ============================================================

if (!isset($pdo)) {
    require_once __DIR__ . '/koneksi.php';
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================================
// SECTION 1 — AUTENTIKASI & SESSION (VERSI ANTI-TABRAKAN)
// ============================================================

/**
 * Cek login Mahasiswa. Redirect ke index.php jika belum login.
 * Mengisolasi session agar tidak bercampur dengan admin.
 */
function cekLogin(): void {
    // 1. Jika data mahasiswa tidak ada, WAJIB dilempar ke index.php
    if (!isset($_SESSION['id_mahasiswa'])) {
        header('Location: index.php');
        exit;
    }

    // 2. KUNCI ISOLASI: Jika dia di halaman mahasiswa tetapi session admin terdeteksi aktif,
    // langsung bersihkan data admin secara paksa dari tab ini agar tidak merusak data mahasiswa.
    if (isset($_SESSION['id_admin'])) {
        unset($_SESSION['id_admin']);
        unset($_SESSION['admin_nama']);
        unset($_SESSION['admin_username']);
        unset($_SESSION['admin_role']);
    }
}

/**
 * Cek login Admin. Dipanggil di setiap file dalam folder /admin/.
 * Redirect ke index.php jika bukan admin.
 */
function cekLoginAdmin(): void {
    // 1. Jika data admin tidak ada
    if (!isset($_SESSION['id_admin'])) {
        
        // Cek apakah request datang dari JavaScript (AJAX/Fetch Live Log)
        $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') 
                  || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);

        if ($isAjax) {
            // Jika yang minta adalah JavaScript Live Log, kirim status eror 401 (Unauthorized)
            // berupa JSON, BUKAN melempar halaman HTML index.php
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Session expired. Please re-login.']);
            exit;
        }

        // Jika diakses manual lewat browser biasa, tendang ke login seperti biasa
        header('Location: ../index.php');
        exit;
    }

    // 2. KUNCI ISOLASI MAHASISWA
    if (isset($_SESSION['id_mahasiswa'])) {
        unset($_SESSION['id_mahasiswa']);
        unset($_SESSION['nama']);
        unset($_SESSION['nim']);
        unset($_SESSION['id_kelas']);
        unset($_SESSION['nama_jurusan']);
        unset($_SESSION['nama_kelas']);
        unset($_SESSION['email']);
        unset($_SESSION['no_telepon']);
        unset($_SESSION['tanggal_lahir']);
        unset($_SESSION['tahun_masuk']);
    }
}

/**
 * Ambil data admin dari session (untuk header, dsb.)
 */
function getAdmin(): array {
    return [
        'id_admin' => $_SESSION['id_admin'] ?? 0,
        'nama'     => $_SESSION['admin_nama']     ?? 'Admin',
        'username' => $_SESSION['admin_username'] ?? '',
        'role'     => $_SESSION['admin_role']     ?? 'admin',
    ];
}

// ============================================================
// SECTION 2 — DATA MAHASISWA
// ============================================================

function getMahasiswa(): array {
    return [
        'id_mahasiswa' => $_SESSION['id_mahasiswa'] ?? 0,
        'nama'         => $_SESSION['nama']          ?? '',
        'nim'          => $_SESSION['nim']           ?? '',
        'id_kelas'     => $_SESSION['id_kelas']      ?? 0,
        'nama_jurusan' => $_SESSION['nama_jurusan']  ?? '',
        'nama_kelas'   => $_SESSION['nama_kelas']    ?? '',
        'email'        => $_SESSION['email']         ?? '',
        'no_telepon'   => $_SESSION['no_telepon']    ?? '',
        'tanggal_lahir'=> $_SESSION['tanggal_lahir'] ?? '',
        'tahun_masuk'  => $_SESSION['tahun_masuk']   ?? '',
        'foto'         => 'https://ui-avatars.com/api/?name=' . urlencode($_SESSION['nama'] ?? 'User')
                          . '&background=144A8C&color=ffffff&size=128',
        'program_studi'=> ($_SESSION['nama_jurusan'] ?? '') . ' ' . ($_SESSION['nama_kelas'] ?? ''),
        'semester'     => 2,
    ];
}

// ============================================================
// SECTION 3 — JADWAL & PRESENSI (MAHASISWA)
// ============================================================

function getJadwalHariIni(PDO $pdo): array {
    $hariMap   = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu',7=>'Minggu'];
    $hariIndex = (int) date('N');
    $hariStr   = $hariMap[$hariIndex] ?? null;
    if (!$hariStr || $hariIndex > 5) return [];

    $idKelas = (int) ($_SESSION['id_kelas'] ?? 0);
    $stmt = $pdo->prepare('
        SELECT j.id_jadwal, mk.nama_matkul, mk.tipe,
               d.nama_dosen, d.gelar,
               j.hari, j.jam_mulai, j.jam_selesai, j.ruangan
          FROM jadwal j
          JOIN mata_kuliah mk ON j.id_matkul = mk.id_matkul
          JOIN dosen d        ON j.id_dosen  = d.id_dosen
         WHERE j.id_kelas = :id_kelas AND j.hari = :hari
         ORDER BY j.jam_mulai ASC
    ');
    $stmt->execute([':id_kelas' => $idKelas, ':hari' => $hariStr]);
    return $stmt->fetchAll();
}

function getJadwalById(PDO $pdo, int $idJadwal): ?array {
    $idKelas = (int) ($_SESSION['id_kelas'] ?? 0);
    $stmt = $pdo->prepare('
        SELECT j.id_jadwal, mk.nama_matkul, mk.tipe,
               d.nama_dosen, d.gelar,
               j.hari, j.jam_mulai, j.jam_selesai, j.ruangan, j.id_kelas
          FROM jadwal j
          JOIN mata_kuliah mk ON j.id_matkul = mk.id_matkul
          JOIN dosen d        ON j.id_dosen  = d.id_dosen
         WHERE j.id_jadwal = :id AND j.id_kelas = :id_kelas
         LIMIT 1
    ');
    $stmt->execute([':id' => $idJadwal, ':id_kelas' => $idKelas]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function getPresensiHariIni(PDO $pdo, int $idJadwal): ?array {
    $idMahasiswa = (int) ($_SESSION['id_mahasiswa'] ?? 0);
    $today       = date('Y-m-d');
    $stmt = $pdo->prepare('
        SELECT * FROM presensi
         WHERE id_mahasiswa = ? AND id_jadwal = ? AND tanggal = ?
         LIMIT 1
    ');
    $stmt->execute([$idMahasiswa, $idJadwal, $today]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function simpanPresensi(PDO $pdo, int $idJadwal, string $status, string $keterangan = '', ?int $idMahasiswa = null): bool {
    if ($idMahasiswa === null) {
        $idMahasiswa = (int) ($_SESSION['id_mahasiswa'] ?? 0);
    }
    if (!$idMahasiswa) {
        return false;
    }

    $today = date('Y-m-d');
    $stmt = $pdo->prepare('
        INSERT INTO presensi (id_mahasiswa, id_jadwal, tanggal, status_kehadiran, keterangan)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            status_kehadiran = VALUES(status_kehadiran),
            keterangan       = VALUES(keterangan),
            waktu_pencatatan = CURRENT_TIMESTAMP
    ');
    return $stmt->execute([$idMahasiswa, $idJadwal, $today, $status, $keterangan]);
}

function periksaAlpaOtomatis(PDO $pdo): void {
    $hariMap   = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu',7=>'Minggu'];
    $hariStr   = $hariMap[(int) date('N')] ?? null;
    if (!$hariStr) {
        return;
    }

    $nowStr = date('H:i:s');
    $stmt = $pdo->prepare('
        SELECT j.id_jadwal, m.id_mahasiswa
          FROM jadwal j
          JOIN kelas_jurusan kj ON j.id_kelas = kj.id_kelas
          JOIN mahasiswa m      ON m.id_kelas = kj.id_kelas
         WHERE j.hari = :hari
           AND j.jam_selesai < :sekarang
    ');
    $stmt->execute([':hari' => $hariStr, ':sekarang' => $nowStr]);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        simpanPresensi($pdo, (int) $row['id_jadwal'], 'Alpa', 'Auto-recorded', (int) $row['id_mahasiswa']);
    }
}

function getRiwayatPresensi(PDO $pdo, string $search = '', string $filterMatkul = '', string $filterStatus = ''): array {
    $idMahasiswa = (int) ($_SESSION['id_mahasiswa'] ?? 0);
    $sql    = '
        SELECT p.tanggal, p.status_kehadiran, p.keterangan, p.waktu_pencatatan,
               mk.nama_matkul, mk.tipe,
               d.nama_dosen, d.gelar,
               j.jam_mulai, j.jam_selesai, j.ruangan, j.hari
          FROM presensi p
          JOIN jadwal j       ON p.id_jadwal  = j.id_jadwal
          JOIN mata_kuliah mk ON j.id_matkul  = mk.id_matkul
          JOIN dosen d        ON j.id_dosen   = d.id_dosen
         WHERE p.id_mahasiswa = :id_mahasiswa
    ';
    $params = [':id_mahasiswa' => $idMahasiswa];
    if ($search !== '') {
        $sql .= ' AND (mk.nama_matkul LIKE :search OR d.nama_dosen LIKE :search2)';
        $params[':search']  = '%' . $search . '%';
        $params[':search2'] = '%' . $search . '%';
    }
    if ($filterMatkul !== '') {
        $sql .= ' AND mk.nama_matkul = :matkul';
        $params[':matkul'] = $filterMatkul;
    }
    if ($filterStatus !== '') {
        $sql .= ' AND p.status_kehadiran = :status';
        $params[':status'] = $filterStatus;
    }
    $sql .= ' ORDER BY p.tanggal DESC, j.jam_mulai DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getDaftarMataKuliah(PDO $pdo): array {
    $idKelas = (int) ($_SESSION['id_kelas'] ?? 0);
    $stmt    = $pdo->prepare('
        SELECT DISTINCT mk.nama_matkul
          FROM jadwal j
          JOIN mata_kuliah mk ON j.id_matkul = mk.id_matkul
         WHERE j.id_kelas = ?
         ORDER BY mk.nama_matkul ASC
    ');
    $stmt->execute([$idKelas]);
    return array_column($stmt->fetchAll(), 'nama_matkul');
}

// ============================================================
// SECTION 4 — UTILITAS WAKTU & FORMAT
// ============================================================

/**
 * Menentukan status jam jadwal saat ini.
 * Return: 'belum' | 'aktif' | 'selesai'
 */
function statusJamJadwal(string $jamMulai, string $jamSelesai): string {
    $now     = strtotime(date('H:i:s'));
    $mulai   = strtotime($jamMulai);
    $selesai = strtotime($jamSelesai);
    if ($now < $mulai)   return 'belum';
    if ($now > $selesai) return 'selesai';
    return 'aktif';
}

function fmtJam(string $time): string {
    return substr($time, 0, 5);
}

function formatTanggalIndo(string $tanggal): string {
    $bulan = ['','Januari','Februari','Maret','April','Mei','Juni',
              'Juli','Agustus','September','Oktober','November','Desember'];
    $ts = strtotime($tanggal);
    return date('d', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
}

function hitungStatistik(array $presensi): array {
    $hadir = $izin = $sakit = $alpa = 0;
    foreach ($presensi as $item) {
        $status = $item['status_kehadiran'] ?? $item['status'] ?? '';
        match ($status) {
            'Hadir' => $hadir++,
            'Izin'  => $izin++,
            'Sakit' => $sakit++,
            default => $alpa++,
        };
    }
    $total      = count($presensi);
    $persentase = $total > 0 ? round(($hadir / $total) * 100, 1) : 0;
    return compact('hadir', 'izin', 'sakit', 'alpa', 'total', 'persentase');
}

function statusKehadiranClass(string $status): string {
    return match ($status) {
        'Hadir' => 'bg-green-100 text-green-700',
        'Izin'  => 'bg-blue-100 text-blue-700',
        'Sakit' => 'bg-yellow-100 text-yellow-700',
        default => 'bg-red-100 text-red-700',
    };
}

// ============================================================
// SECTION 5 — UI RENDER (Mahasiswa)
// ============================================================

function renderHeader(string $title = 'PORTAL MAHASISWA', string $subtitle = 'Sistem Presensi'): void {
    // Menghilangkan 'max-w-md mx-auto' agar layout membentang penuh ke pojok kiri dan kanan halaman
    echo '<header class="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-40 w-full">';
    echo '<div class="w-full flex items-center justify-between">';
    echo '<div class="text-left">'; // Memastikan teks dipaksa rata kiri
    echo '<h1 class="text-base font-extrabold text-[#144A8C] tracking-wide uppercase leading-tight">' . htmlspecialchars($title) . '</h1>';
    echo '<p class="text-xs font-medium text-gray-400 mt-0.5">' . htmlspecialchars($subtitle) . '</p></div>';
    echo '<div class="w-9 h-9 flex items-center justify-center">';
    echo '<img src="asset/logo.png" alt="Logo" class="max-h-full object-contain">';
    echo '</div></div></header>';
}

function renderBackHeader(string $title = '', string $subtitle = '', string $backUrl = 'dashboard.php'): void {
    echo '<header class="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-40">';
    echo '<div class="max-w-md mx-auto flex items-center gap-3">';
    echo '<a href="' . $backUrl . '" class="text-gray-600 hover:text-[#1F5DAA] w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100">';
    echo '<i class="fas fa-arrow-left text-lg"></i></a><div>';
    if ($title)    echo '<h1 class="text-sm font-bold text-[#1F5DAA] leading-tight">' . htmlspecialchars($title) . '</h1>';
    if ($subtitle) echo '<p class="text-[10px] text-gray-400">' . htmlspecialchars($subtitle) . '</p>';
    echo '</div></div></header>';
}

function renderBottomNav($page_aktif = 'dashboard') {
    $home_class    = ($page_aktif == 'dashboard') ? 'text-[#1F5DAA] font-semibold' : 'text-gray-400 hover:text-gray-600';
    $riwayat_class = ($page_aktif == 'riwayat')   ? 'text-[#1F5DAA] font-semibold' : 'text-gray-400 hover:text-gray-600';
    $profile_class = ($page_aktif == 'profile')   ? 'text-[#1F5DAA] font-semibold' : 'text-gray-400 hover:text-gray-600';
    ?>

    <aside id="sidebarDesktop" class="hidden lg:flex flex-col fixed left-0 top-0 w-64 h-screen bg-white border-r border-gray-100 z-50 transition-all duration-300 transform translate-x-0">
        
        <div class="p-5 border-b border-gray-50 flex items-center gap-3 sidebar-brand">
    <div class="w-10 h-10 bg-gradient-to-tr from-[#144A8C] to-[#1F5DAA] rounded-xl flex items-center justify-center text-white shadow-md flex-shrink-0">
        <i class="fas fa-graduation-cap text-lg"></i>
    </div>
    <div class="sidebar-text">
        <h1 class="text-sm font-bold text-gray-800 tracking-wide uppercase">Portal Presensi</h1>
        <p class="text-[10px] text-gray-400 font-medium">Mahasiswa v1.0</p>
    </div>
</div>

        <nav class="flex-1 p-4 space-y-1.5">
            <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm <?php echo ($page_aktif == 'dashboard') ? 'bg-blue-50 text-[#144A8C] font-bold shadow-sm' : 'text-gray-500 hover:bg-gray-50'; ?>">
                <i class="fas fa-home text-base w-5 text-center flex-shrink-0"></i>
                <span class="sidebar-text">Dashboard</span>
            </a>
            <a href="riwayat.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm <?php echo ($page_aktif == 'riwayat') ? 'bg-blue-50 text-[#144A8C] font-bold shadow-sm' : 'text-gray-500 hover:bg-gray-50'; ?>">
                <i class="fas fa-history text-base w-5 text-center flex-shrink-0"></i>
                <span class="sidebar-text">Riwayat Presensi</span>
            </a>
            <a href="profile.php" class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm <?php echo ($page_aktif == 'profile') ? 'bg-blue-50 text-[#144A8C] font-bold shadow-sm' : 'text-gray-500 hover:bg-gray-50'; ?>">
                <i class="fas fa-user text-base w-5 text-center flex-shrink-0"></i>
                <span class="sidebar-text">Profil Anda</span>
            </a>
        </nav>

        <div class="p-4 border-t border-gray-50">
            <a href="logout.php" onclick="return confirm('Yakin ingin keluar aplikasi?')" class="flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 text-sm font-medium transition-all">
                <i class="fas fa-sign-out-alt text-base w-5 text-center flex-shrink-0"></i>
                <span class="sidebar-text">Keluar Sistem</span>
            </a>
        </div>
    </aside>

    <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-2 flex justify-around items-center z-50 lg:hidden shadow-lg">
        <a href="dashboard.php" class="flex flex-col items-center gap-0.5 <?php echo $home_class; ?>">
            <i class="fas fa-home text-lg"></i>
            <span class="text-[10px]">Home</span>
        </a>
        <a href="riwayat.php" class="flex flex-col items-center gap-0.5 <?php echo $riwayat_class; ?>">
            <i class="fas fa-list-alt text-lg"></i>
            <span class="text-[10px]">Riwayat</span>
        </a>
        <a href="profile.php" class="flex flex-col items-center gap-0.5 <?php echo $profile_class; ?>">
            <i class="fas fa-user text-lg"></i>
            <span class="text-[10px]">Profile</span>
        </a>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const sidebar = document.getElementById('sidebarDesktop');
        const mainWrapper = document.getElementById('mainContentWrapper');
        const btnToggle = document.getElementById('btnToggleSidebar');
        const btnFloating = document.getElementById('btnFloatingToggle');

        if(sidebar && mainWrapper) {
            // Cek status penyimpanan sidebar sebelumnya di browser biar gak reset tiap pindah halaman
            const isClosed = localStorage.getItem('sidebarClosed') === 'true';
            if (isClosed && window.innerWidth >= 1024) {
                applySidebarClosed();
            }

            function applySidebarClosed() {
                sidebar.classList.remove('w-64');
                sidebar.classList.add('w-20');
                mainWrapper.classList.remove('lg:pl-64');
                mainWrapper.classList.add('lg:pl-20');
                
                // Menyembunyikan text menu, menyisakan icon saja seperti Gemini mini-sidebar
                document.querySelectorAll('.sidebar-text').forEach(el => el.classList.add('lg:hidden'));
                document.querySelectorAll('.sidebar-brand').forEach(el => el.classList.add('lg:justify-center'));
            }

            function applySidebarOpen() {
                sidebar.classList.remove('w-20');
                sidebar.classList.add('w-64');
                mainWrapper.classList.remove('lg:pl-20');
                mainWrapper.classList.add('lg:pl-64');
                
                document.querySelectorAll('.sidebar-text').forEach(el => el.classList.remove('lg:hidden'));
                document.querySelectorAll('.sidebar-brand').forEach(el => el.classList.remove('lg:justify-center'));
            }

            // Fungsi ketika tombol hamburger diklik
            function toggleSidebar() {
                if (sidebar.classList.contains('w-64')) {
                    applySidebarClosed();
                    localStorage.setItem('sidebarClosed', 'true');
                } else {
                    applySidebarOpen();
                    localStorage.setItem('sidebarClosed', 'false');
                }
            }

            if(btnFloating) btnFloating.addEventListener('click', toggleSidebar);
        }
    });
    </script>
    <?php
}

function renderFlashMessage(): void {
    if (isset($_SESSION['flash'])) {
        $flash   = $_SESSION['flash'];
        $bgClass = $flash['type'] === 'success'
            ? 'bg-green-100 border-green-400 text-green-700'
            : 'bg-red-100 border-red-400 text-red-700';
        echo '<div class="' . $bgClass . ' border px-4 py-3 rounded-xl mb-4 text-sm">';
        echo '<p class="font-medium">' . htmlspecialchars($flash['message']) . '</p></div>';
        unset($_SESSION['flash']);
    }
}

function setFlash(string $message, string $type = 'success'): void {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}
?>