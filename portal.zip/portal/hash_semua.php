<?php
require_once 'koneksi.php';

try {
    // 1. Ambil semua data mahasiswa yang ada di database
    $stmt = $pdo->query("SELECT id_mahasiswa, nim FROM mahasiswa");
    $mahasiswa_list = $stmt->fetchAll();

    echo "<h2>Proses Enkripsi Password Mahasiswa</h2>";
    echo "Total data ditemukan: " . count($mahasiswa_list) . " mahasiswa.<br><br>";

    // 2. Lakukan perulangan untuk mengupdate setiap mahasiswa
    $update_stmt = $pdo->prepare("UPDATE mahasiswa SET password = ? WHERE id_mahasiswa = ?");
    
    foreach ($mahasiswa_list as $mhs) {
        // Kita set password default-nya sama dengan NIM masing-masing mahasiswa agar mudah ditest
        $password_polos = $mhs['nim']; 
        
        // Enkripsi password menggunakan password_hash bawaan PHP
        $password_hash = password_hash($password_polos, PASSWORD_DEFAULT);
        
        // Eksekusi update ke database
        $update_stmt->execute([$password_hash, $mhs['id_mahasiswa']]);
        
        echo "✓ Mahasiswa NIM: <b>{$mhs['nim']}</b> berhasil diupdate. (Password login: <u>{$password_polos}</u>)<br>";
    }

    echo "<br><b>Selesai!</b> Semua password mahasiswa sekarang sudah terenkripsi dengan sistem hash.";
    echo "<br>Silakan coba login kembali di halaman login utama.";

} catch (PDOException $e) {
    echo "Terjadi kesalahan database: " . $e->getMessage();
}
?>