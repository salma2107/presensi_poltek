<?php
// ============================================================
// INDEX.PHP — Login Terpadu: Mahasiswa & Admin
// ============================================================
require_once 'koneksi.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bersihkan otomatis jika halaman login diakses kembali agar tidak saling mengunci
// if (isset($_SESSION['id_admin'])) {
//     header('Location: admin/dashboard.php'); exit;
// }
// if (isset($_SESSION['id_mahasiswa'])) {
//     header('Location: dashboard.php'); exit;
// }

$errors = [];
$nim    = '';
$role   = 'mahasiswa'; // default tab

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role     = $_POST['role']     ?? 'mahasiswa';
    $nim      = trim($_POST['nim'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    // ---- LOGIN MAHASISWA ----
    if ($role === 'mahasiswa') {
        if (empty($nim))      $errors['nim']      = 'NIM wajib diisi';
        if (empty($password)) $errors['password'] = 'Password wajib diisi';

        if (empty($errors)) {
            $stmt = $pdo->prepare('
                SELECT m.id_mahasiswa, m.nama, m.nim, m.password, m.id_kelas,
                       m.email, m.no_telepon, m.tanggal_lahir, m.tahun_masuk,
                       kj.nama_jurusan, kj.nama_kelas
                  FROM mahasiswa m
                  JOIN kelas_jurusan kj ON m.id_kelas = kj.id_kelas
                 WHERE m.nim = ? LIMIT 1
            ');
            $stmt->execute([$nim]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // SEBELUM LOGIN MAHASISWA: Bersihkan session admin jika ada agar tidak tabrakan
                unset($_SESSION['id_admin']);
                unset($_SESSION['admin_nama']);
                unset($_SESSION['admin_username']);
                unset($_SESSION['admin_role']);

                // Regenerate ID agar session baru benar-benar bersih dan aman
                session_regenerate_id(true);

                // Daftarkan session mahasiswa seperti biasa
                $_SESSION['id_mahasiswa'] = $user['id_mahasiswa'];
                $_SESSION['nama']         = $user['nama'];
                $_SESSION['nim']          = $user['nim'];
                $_SESSION['id_kelas']     = $user['id_kelas'];
                $_SESSION['nama_jurusan'] = $user['nama_jurusan'];
                $_SESSION['nama_kelas']   = $user['nama_kelas'];
                $_SESSION['email']        = $user['email'];
                $_SESSION['no_telepon']   = $user['no_telepon'];
                $_SESSION['tanggal_lahir']= $user['tanggal_lahir'];
                $_SESSION['tahun_masuk']  = $user['tahun_masuk'];

                header('Location: dashboard.php');
                exit;
            }
        }

    // ---- LOGIN ADMIN ----
    } else {
        if (empty($username)) $errors['username'] = 'Username wajib diisi';
        if (empty($password)) $errors['password'] = 'Password wajib diisi';

        if (empty($errors)) {
            $stmt = $pdo->prepare('SELECT * FROM admin WHERE username = ? LIMIT 1');
            $stmt->execute([$username]);
            $admin = $stmt->fetch();

            // ---- DI DALAM PROSES LOGIN ADMIN YANG BERJAYA ----
            if ($admin && password_verify($password, $admin['password'])) {
                
                // SEBELUM SIMPAN DATA ADMIN: Bersihkan semua session mahasiswa
                unset($_SESSION['id_mahasiswa']);
                unset($_SESSION['nama']);
                unset($_SESSION['nim']);
                unset($_SESSION['id_kelas']);
                unset($_SESSION['nama_jurusan']);
                unset($_SESSION['nama_kelas']);
                
                // Jalankan penukaran ID Session baharu demi keselamatan
                session_regenerate_id(true);

                // Simpan data session admin seperti biasa
                $_SESSION['id_admin']       = $admin['id_admin'];
                $_SESSION['admin_nama']     = $admin['nama'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_role']     = $admin['role'];

                header('Location: admin/dashboard.php');
                exit;
            }
        }
    }
}

if (isset($_COOKIE['remember_nim']) && empty($nim)) {
    $nim = $_COOKIE['remember_nim'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login - Portal Mahasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @keyframes fadeInUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
        @keyframes pulse-ring {
            0%{transform:scale(.95);box-shadow:0 0 0 0 rgba(244,182,63,.7)}
            70%{transform:scale(1);box-shadow:0 0 0 10px rgba(244,182,63,0)}
            100%{transform:scale(.95);box-shadow:0 0 0 0 rgba(244,182,63,0)}
        }
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes shake{0%,100%{transform:translateX(0)}10%,30%,50%,70%,90%{transform:translateX(-5px)}20%,40%,60%,80%{transform:translateX(5px)}}
        .animate-fade-in-up{animation:fadeInUp .7s ease-out forwards}
        .animate-pulse-ring{animation:pulse-ring 2s infinite}
        .animate-shake{animation:shake .5s ease-in-out}
        .loading-overlay{position:fixed;inset:0;background:rgba(20,74,140,.9);display:flex;align-items:center;justify-content:center;z-index:9999;opacity:0;pointer-events:none;transition:opacity .3s}
        .loading-overlay.active{opacity:1;pointer-events:all}
        .loading-spinner{width:50px;height:50px;border:4px solid rgba(255,255,255,.3);border-top-color:#F4B63F;border-radius:50%;animation:spin 1s linear infinite}
        .phone-frame{max-width:414px;margin:0 auto;min-height:100vh;background:linear-gradient(180deg,#144A8C 0%,#1F5DAA 40%,#3B82F6 100%);position:relative;overflow-x:hidden}
        .deco-circle{position:absolute;border-radius:50%;background:rgba(255,255,255,.05)}
        .input-login{transition:all .2s ease}
        .input-login:focus{border-color:#1F5DAA;box-shadow:0 0 0 3px rgba(31,93,170,.15)}
        .tab-btn{transition:all .2s ease}
        .tab-btn.active{background:rgba(255,255,255,.25);color:#fff}
        .tab-btn:not(.active){color:rgba(255,255,255,.6)}
        
        /* Modal Backdrop Utilities */
        .modal-blur { backdrop-filter: blur(4px); transition: all 0.3s ease-out; }
    </style>
</head>
<body class="min-h-screen flex flex-col justify-between relative overflow-x-hidden antialiased text-white font-medium" style="background: linear-gradient(180deg, #144A8C 0%, #1F5DAA 40%, #3B82F6 100%);">
<div class="loading-overlay" id="loadingOverlay">
    <div class="flex flex-col items-center gap-4">
        <div class="loading-spinner"></div>
        <p class="text-white font-medium text-sm">Memuat...</p>
    </div>
</div>
<div class="phone-frame">
    <div class="w-full flex justify-between items-center px-6 pt-3 pb-2 text-xs z-10 sm:hidden">
        <span><?php echo date('H:i'); ?></span>
        <div class="flex items-center gap-1">
            <i class="fas fa-signal text-[10px]"></i>
            <i class="fas fa-wifi text-[10px]"></i>
            <i class="fas fa-battery-full text-[10px]"></i>
        </div>
    </div>
    <div class="px-6 py-8 flex flex-col items-center justify-center flex-1 z-10 w-full">
        <div class="animate-fade-in-up flex flex-col items-center mb-8" style="animation-delay:.1s;">
            <div class="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#F4B63F] to-[#FDE68A] flex items-center justify-center shadow-lg mb-4 animate-pulse-ring">
                <img src="asset/logo.png" style="border-radius:8px;" alt="Logo">
            </div>
            <h1 class="text-white font-bold text-xl tracking-wide">PORTAL MAHASISWA</h1>
            <p class="text-blue-200 text-xs mt-1">Sistem Presensi Kehadiran</p>
        </div>

        <div class="w-full flex bg-white/10 rounded-xl p-1 mb-5">
            <button type="button" id="tabMahasiswa"
                    onclick="switchTab('mahasiswa')"
                    class="tab-btn flex-1 py-2 rounded-lg text-sm font-semibold <?php echo $role === 'mahasiswa' ? 'active' : ''; ?>">
                <i class="fas fa-user-graduate mr-1"></i> Mahasiswa
            </button>
            <button type="button" id="tabAdmin"
                    onclick="switchTab('admin')"
                    class="tab-btn flex-1 py-2 rounded-lg text-sm font-semibold <?php echo $role === 'admin' ? 'active' : ''; ?>">
                <i class="fas fa-user-shield mr-1"></i> Admin
            </button>
        </div>

        <div class="w-full sm:max-w-[366px] animate-fade-in-up" style="animation-delay:.2s;">
        <div class="bg-gradient-to-br from-[#FDE68A] via-[#F4B63F] to-[#F59E0B] rounded-3xl p-6 shadow-2xl">
            <?php if (isset($errors['login'])): ?>
            <div class="bg-red-100 border border-red-300 text-red-700 px-4 py-3 rounded-xl mb-4 text-sm animate-shake">
                <div class="flex items-center gap-2">
                    <i class="fas fa-exclamation-circle"></i>
                    <span class="font-medium"><?php echo htmlspecialchars($errors['login']); ?></span>
                </div>
            </div>
            <?php endif; ?>

                <form action="" method="POST" id="loginForm" onsubmit="return validateForm(event)" class="space-y-4">
                    <input type="hidden" name="role" id="roleInput" value="<?php echo htmlspecialchars($role); ?>">

                    <div id="fieldMahasiswa" class="<?php echo $role === 'admin' ? 'hidden' : ''; ?>">
                        <label class="block text-sm font-semibold text-gray-800 mb-1.5">NIM</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <i class="fas fa-id-card text-gray-400 text-sm"></i>
                            </div>
                            <input type="text" name="nim" value="<?php echo htmlspecialchars($nim); ?>"
                                   placeholder="Masukkan NIM Anda"
                                   class="input-login w-full pl-10 pr-4 py-3 bg-white/90 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none">
                        </div>
                        <?php if (isset($errors['nim'])): ?>
                        <p class="text-red-700 text-xs mt-1"><?php echo htmlspecialchars($errors['nim']); ?></p>
                        <?php endif; ?>
                    </div>

                    <div id="fieldAdmin" class="<?php echo $role !== 'admin' ? 'hidden' : ''; ?>">
                        <label class="block text-sm font-semibold text-gray-800 mb-1.5">Username Admin</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <i class="fas fa-user-shield text-gray-400 text-sm"></i>
                            </div>
                            <input type="text" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                                   placeholder="Username admin"
                                   class="input-login w-full pl-10 pr-4 py-3 bg-white/90 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none">
                        </div>
                        <?php if (isset($errors['username'])): ?>
                        <p class="text-red-700 text-xs mt-1"><?php echo htmlspecialchars($errors['username']); ?></p>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-800 mb-1.5">Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400 text-sm"></i>
                            </div>
                            <input type="password" name="password" id="passwordInput" placeholder="Masukkan Password"
                                   class="input-login w-full pl-10 pr-10 py-3 bg-white/90 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none">
                            <button type="button" onclick="togglePwd()" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <i class="fas fa-eye text-gray-400 text-sm" id="eyeIcon"></i>
                            </button>
                        </div>
                        <?php if (isset($errors['password'])): ?>
                        <p class="text-red-700 text-xs mt-1"><?php echo htmlspecialchars($errors['password']); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="bg-[#F9F9F9] border border-gray-300 rounded-lg p-3 flex items-center justify-between shadow-sm select-none h-[65px]">
                        <div class="flex items-center gap-3">
                            <div id="captchaIconContainer" class="flex items-center justify-center w-8 h-8">
                                <div class="w-5 h-5 border-2 border-gray-300 border-top-2 border-t-blue-600 rounded-full animate-spin" id="captchaSpinner"></div>
                                <div class="hidden text-emerald-600 text-2xl" id="captchaSuccessIcon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                            <span id="captchaStatusText" class="text-sm font-normal text-gray-500 tracking-wide">Verifying...</span>
                        </div>
                        <div class="flex flex-col items-end justify-center pr-1">
                            <div class="flex items-center gap-1">
                                <span class="text-[10px] font-black text-gray-800 tracking-tighter uppercase">Cloudflare</span>
                                <i class="fas fa-cloud text-amber-500 text-xs"></i>
                            </div>
                            <div class="flex gap-1 text-[8px] text-gray-400 underline mt-0.5">
                                <a href="#" onclick="alert('Protected by simulated security.'); return false;">Privacy</a>
                                <span>•</span>
                                <a href="#" onclick="alert('Automated challenge protection.'); return false;">Help</a>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="captchaVerified" value="0">

                    <div class="flex items-center justify-between">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="remember" class="w-4 h-4 rounded border-gray-300">
                            <span class="text-sm text-gray-700">Ingat Saya</span>
                        </label>
                        <button type="button" onclick="openModal('baakNotificationModal')" class="text-sm text-[#1F5DAA] font-medium hover:underline focus:outline-none">Lupa Password?</button>
                    </div>

                    <button type="submit" id="submitBtn" disabled
                            class="w-full bg-gray-400 text-white font-semibold py-3.5 rounded-xl shadow-lg transition-all duration-300 cursor-not-allowed">
                        <i class="fas fa-sign-in-alt mr-2"></i>Masuk
                    </button>
                </form>
            </div>
        </div>

        <div class="mt-4 text-center animate-fade-in-up" style="animation-delay:.3s;">
            <p class="text-blue-200 text-sm">Belum punya akun? <button type="button" onclick="openModal('baakNotificationModal')" class="text-white font-semibold hover:underline focus:outline-none">Hubungi Admin</button></p>
        </div>
    </div>
</div>

<div id="baakNotificationModal" class="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 modal-blur hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white text-gray-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl relative transform scale-95 transition-transform duration-300">
        <button type="button" onclick="closeModal('baakNotificationModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors">
            <i class="fas fa-times text-lg"></i>
        </button>
        <div class="flex flex-col items-center text-center">
            <div class="w-14 h-14 rounded-full bg-amber-50 flex items-center justify-center text-amber-500 text-2xl mb-4 border border-amber-200">
                <i class="fas fa-id-card-alt"></i>
            </div>
            <h3 class="text-base font-bold text-gray-900 mb-2">Pemberitahuan Layanan</h3>
            <p class="text-xs text-gray-600 mb-5 leading-relaxed">
                Untuk keperluan <span class="font-semibold text-gray-900">reset password</span> maupun <span class="font-semibold text-gray-900">registrasi pembuatan akun baru</span>, silakan datang langsung ke loket <span class="font-bold text-[#1F5DAA]">BAAK</span> dengan membawa <span class="font-bold text-red-600">Kartu Identitas Mahasiswa (KTM)</span> asli sebagai bukti verifikasi kepemilikan akun.
            </p>
            <button type="button" onclick="closeModal('baakNotificationModal')"
               class="w-full text-center bg-gradient-to-r from-[#1F5DAA] to-[#3B82F6] text-white font-semibold py-2.5 rounded-xl shadow-md hover:from-[#144A8C] hover:to-[#1F5DAA] transition-all text-xs">
                Saya Mengerti
            </button>
        </div>
    </div>
</div>

<div class="deco-circle w-64 h-64 -top-20 -left-20"></div>
<div class="deco-circle w-48 h-48 top-40 -right-16"></div>
<div class="deco-circle w-32 h-32 bottom-20 left-10"></div>

<script>
function switchTab(role) {
    document.getElementById('roleInput').value = role;
    document.getElementById('fieldMahasiswa').classList.toggle('hidden', role !== 'mahasiswa');
    document.getElementById('fieldAdmin').classList.toggle('hidden', role !== 'admin');
    document.getElementById('tabMahasiswa').classList.toggle('active', role === 'mahasiswa');
    document.getElementById('tabAdmin').classList.toggle('active', role === 'admin');
}
function togglePwd() {
    const i = document.getElementById('passwordInput');
    const e = document.getElementById('eyeIcon');
    i.type = i.type === 'password' ? 'text' : 'password';
    e.classList.toggle('fa-eye'); e.classList.toggle('fa-eye-slash');
}

// ---- LOGIKA JAVASCRIPT: SIMULASI OTOMATIS CAPTCHA CLOUDFLARE ----
document.addEventListener("DOMContentLoaded", function() {
    setTimeout(function() {
        // Sembunyikan spinner loading captcha, ganti ke tanda centang sukses hijau
        document.getElementById('captchaSpinner').classList.add('hidden');
        document.getElementById('captchaSuccessIcon').classList.remove('hidden');
        
        // Ubah teks status menjadi "Success!"
        const statusText = document.getElementById('captchaStatusText');
        statusText.innerText = "Success!";
        statusText.classList.remove('text-gray-500');
        statusText.classList.add('text-gray-800', 'font-semibold');
        
        // Tandai input captcha terverifikasi
        document.getElementById('captchaVerified').value = "1";
        
        // Aktifkan kembali tombol submit dengan mengembalikan style warna gradasi aslinya
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.removeAttribute('disabled');
        submitBtn.classList.remove('bg-gray-400', 'cursor-not-allowed');
        submitBtn.classList.add('bg-gradient-to-r', 'from-[#1F5DAA]', 'to-[#3B82F6]', 'hover:from-[#144A8C]', 'hover:to-[#1F5DAA]', 'transform', 'hover:-translate-y-0.5');
    }, 1500); // Waktu jeda verifikasi otomatis selama 1.5 detik
});

function validateForm(event) {
    const isVerified = document.getElementById('captchaVerified').value;
    if (isVerified !== "1") {
        event.preventDefault();
        return false;
    }
    document.getElementById('loadingOverlay').classList.add('active');
    return true;
}

// ---- LOGIKA JAVASCRIPT: OPERASIONAL POP-UP MODAL ----
function openModal(id) {
    const modal = document.getElementById(id);
    const content = modal.querySelector('div');
    
    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.classList.remove('opacity-0');
        content.classList.remove('scale-95');
        content.classList.add('scale-100');
    }, 20);
}

function closeModal(id) {
    const modal = document.getElementById(id);
    const content = modal.querySelector('div');
    
    modal.classList.add('opacity-0');
    content.classList.remove('scale-100');
    content.classList.add('scale-95');
    
    setTimeout(() => {
        modal.classList.add('hidden');
    }, 300);
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal-blur')) {
        closeModal(event.target.id);
    }
}
</script>
</body>
</html>