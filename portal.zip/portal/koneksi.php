<?php
// ============================================================
// KONEKSI.PHP — Konfigurasi & Koneksi Database MySQL
// Salin file ini ke folder proyek Anda di XAMPP (htdocs/portal_absensi/)
// ============================================================

// Sesuaikan dengan konfigurasi XAMPP lokal Anda
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // Default XAMPP kosong
define('DB_NAME', 'portal_absensi');
define('DB_CHARSET', 'utf8mb4');

// Timezone wajib Indonesia
date_default_timezone_set('Asia/Jakarta');

// Buat koneksi PDO (lebih aman dari mysqli)
try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    // Tampilkan pesan ramah di production; di development bisa echo detail
    die('<div style="font-family:sans-serif;padding:20px;color:#c0392b;">
        <h2>⚠️ Gagal Terhubung ke Database</h2>
        <p>Pastikan XAMPP MySQL sudah berjalan dan database <strong>portal_absensi</strong> sudah dibuat.</p>
        <small>Error: ' . htmlspecialchars($e->getMessage()) . '</small>
    </div>');
}