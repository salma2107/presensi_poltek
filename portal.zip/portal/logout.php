<?php
session_start();

// Hapus hanya data session milik mahasiswa
unset($_SESSION['id_mahasiswa']);
unset($_SESSION['nama']);
unset($_SESSION['nim']);
unset($_SESSION['id_kelas']);
unset($_SESSION['nama_jurusan']);
unset($_SESSION['nama_kelas']);
unset($_SESSION['email']);
unset($_SESSION['no_telepon']);
unset($_SESSION['tanggal_lahir']);
unset($_SESSION['tahun_masuk']);

// Arahkan kembali ke halaman login
header("Location: index.php");
exit;