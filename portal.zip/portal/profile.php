<?php
/**
 * =============================================================================
 * PROFILE.PHP - HALAMAN PROFIL MAHASISWA
 * =============================================================================
 * Menggunakan DUMMY DATA (array PHP) — tidak ada database.
 * Menampilkan data pribadi mahasiswa dengan fitur:
 * - Tampilan data profil
 * - Edit profil (form POST → update data session)
 * =============================================================================
 */

require_once 'koneksi.php';
require_once 'functions.php';

// Cek autentikasi
cekLogin();

// Ambil data mahasiswa
$dataMahasiswa = getMahasiswa();

// Mode edit
$isEdit = isset($_GET['edit']) && $_GET['edit'] === '1';

// Proses update profile (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $errors = [];
    
    // Validasi nama wajib diisi
    $nama = trim($_POST['nama'] ?? '');
    if (empty($nama)) {
        $errors['nama'] = 'Nama lengkap wajib diisi';
    }
    
    // Validasi email
    $email = trim($_POST['email'] ?? '');
    if (empty($email)) {
        $errors['email'] = 'Email wajib diisi';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Format email tidak valid';
    }
    
    // Validasi no telepon
    $no_telepon = trim($_POST['no_telepon'] ?? '');
    if (empty($no_telepon)) {
        $errors['no_telepon'] = 'No Telepon wajib diisi';
    }
    
    // Validasi tanggal lahir
    $tanggal_lahir = trim($_POST['tanggal_lahir'] ?? '');
    if (empty($tanggal_lahir)) {
        $errors['tanggal_lahir'] = 'Tanggal lahir wajib diisi';
    }
    
    // Jika tidak ada error, update data
    if (empty($errors)) {
        updateMahasiswa([
            'nama'          => $nama,
            'email'         => $email,
            'no_telepon'    => $no_telepon,
            'tanggal_lahir' => $tanggal_lahir,
        ]);
        
        setFlash('Profil berhasil diperbarui!', 'success');
        header('Location: profile.php');
        exit;
    }
}

// Ganti password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ganti_password'])) {
    $passLama = $_POST['password_lama'] ?? '';
    $passBaru = $_POST['password_baru'] ?? '';
    $konfirm  = $_POST['konfirmasi']    ?? '';
 
    $stmt = $pdo->prepare('SELECT password FROM mahasiswa WHERE id_mahasiswa=?');
    $stmt->execute([$dataMahasiswa['id_mahasiswa']]);
    $hashLama = $stmt->fetchColumn();
 
    if (!password_verify($passLama, $hashLama)) {
        $pesanError = 'Password lama tidak sesuai.';
    } elseif (strlen($passBaru) < 6) {
        $pesanError = 'Password baru minimal 6 karakter.';
    } elseif ($passBaru !== $konfirm) {
        $pesanError = 'Konfirmasi password tidak cocok.';
    } else {
        $hashBaru = password_hash($passBaru, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE mahasiswa SET password=? WHERE id_mahasiswa=?');
        if ($stmt->execute([$hashBaru, $dataMahasiswa['id_mahasiswa']])) {
            $pesanSukses = 'Password berhasil diubah!';
        } else {
            $pesanError = 'Gagal mengubah password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Profil - Portal Mahasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        
        .animate-fade-in-up {
            animation: fadeInUp 0.5s ease-out forwards;
        }
        .animate-scale-in {
            animation: scaleIn 0.4s ease-out forwards;
        }
        
        /* Input styling */
        .profile-input {
            transition: all 0.2s ease;
        }
        .profile-input:focus {
            border-color: #1F5DAA;
            box-shadow: 0 0 0 3px rgba(31, 93, 170, 0.1);
        }
        
        /* Card hover */
        .info-card {
            transition: all 0.2s ease;
        }
        .info-card:hover {
            border-color: #3B82F6;
            background: #F8FAFC;
        }
    </style>
</head>
<body class="bg-gray-50 pb-16 lg:pb-0 text-gray-800">

    <?php renderBottomNav('riwayat'); ?>

    <div id="mainContentWrapper" class="w-full lg:pl-64 min-h-screen transition-all duration-300">
        <div class="w-full bg-white min-h-screen shadow-sm flex flex-col">
            <?php renderHeader('PORTAL MAHASISWA', 'Sistem Presensi'); ?>
        
        <!-- Flash Message -->
        <div class="px-4 pt-3">
            <?php renderFlashMessage(); ?>
        </div>
        
        <!-- Main Content -->
        <main class="px-4 py-3 space-y-4">
            
            <!-- Page Title -->
            <div class="animate-fade-in-up" style="animation-delay: 0.05s;">
                <h2 class="text-xl font-bold text-gray-900">Profile Mahasiswa</h2>
                <p class="text-[11px] text-gray-400 mt-0.5">Kelola informasi dan data akademik Anda</p>
            </div>
            
            <!-- Profile Card -->
            <div class="animate-fade-in-up" style="animation-delay: 0.1s;">
                <div class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA] rounded-2xl p-5 text-white shadow-lg relative overflow-hidden">
                    <!-- Decorative circles -->
                    <div class="absolute top-0 right-0 w-28 h-28 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                    <div class="absolute bottom-0 left-0 w-16 h-16 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
                    
                    <div class="relative z-10 flex items-center gap-4">
                        <!-- Avatar -->
                        <div class="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-sm border-2 border-white/30 shrink-0">
                            <img src="<?php echo $dataMahasiswa['foto']; ?>" 
                                 alt="<?php echo htmlspecialchars($dataMahasiswa['nama']); ?>" 
                                 class="w-14 h-14 rounded-xl object-cover">
                        </div>
                        
                        <!-- Info -->
                        <div class="min-w-0">
                            <h3 class="font-bold text-base truncate"><?php echo htmlspecialchars($dataMahasiswa['nama']); ?></h3>
                            <p class="text-blue-200 text-xs mt-0.5">NIM : <?php echo htmlspecialchars($dataMahasiswa['nim']); ?></p>
                            <div class="flex items-center gap-2 mt-1.5 text-[10px] text-blue-300/80">
                                <span class="flex items-center gap-1">
                                    <i class="fas fa-graduation-cap text-[9px]"></i>
                                    <?php echo htmlspecialchars($dataMahasiswa['program_studi']); ?>
                                </span>
                                <span>•</span>
                                <span>Semester <?php echo $dataMahasiswa['semester']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Data Pribadi -->
            <div class="animate-fade-in-up" style="animation-delay: 0.15s;">
                <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                                <i class="fas fa-id-card text-[#3B82F6] text-sm"></i>
                            </div>
                            <h3 class="font-semibold text-gray-800 text-sm">Data Pribadi</h3>
                        </div>
                        
                        <?php if (!$isEdit): ?>
                        <a href="profile.php?edit=1" class="text-[11px] bg-gradient-to-r from-[#F4B63F] to-[#F59E0B] hover:from-[#F59E0B] hover:to-[#D97706] text-white font-medium px-3 py-1.5 rounded-lg shadow-sm transition-all duration-200 flex items-center gap-1">
                            <i class="fas fa-pen text-[10px]"></i>
                            Edit Profil
                        </a>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($isEdit): ?>
                    <!-- Edit Form -->
                    <form action="" method="POST" class="space-y-4 animate-scale-in">
                        <input type="hidden" name="update_profile" value="1">
                        
                        <!-- Nama Lengkap -->
                        <div>
                            <label class="block text-[11px] font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Nama Lengkap</label>
                            <input 
                                type="text" 
                                name="nama" 
                                value="<?php echo htmlspecialchars($dataMahasiswa['nama']); ?>"
                                disabled
                                class="w-full px-3.5 py-2.5 bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-500 cursor-not-allowed"
                            >
                        </div>
                        
                        <!-- NIM (readonly) -->
                        <div>
                            <label class="block text-[11px] font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">NIM</label>
                            <input 
                                type="text" 
                                value="<?php echo htmlspecialchars($dataMahasiswa['nim']); ?>"
                                disabled
                                class="w-full px-3.5 py-2.5 bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-500 cursor-not-allowed"
                            >
                        </div>
                        
                        <!-- Email -->
                        <div>
                            <label class="block text-[11px] font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Email</label>
                            <input 
                                type="email" 
                                name="email" 
                                value="<?php echo htmlspecialchars($dataMahasiswa['email']); ?>"
                                class="profile-input w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none"
                            >
                            <?php if (isset($errors['email'])): ?>
                            <p class="text-red-500 text-[10px] mt-1 flex items-center gap-1">
                                <i class="fas fa-exclamation-circle text-[9px]"></i>
                                <?php echo htmlspecialchars($errors['email']); ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        
                        <!-- No Telepon -->
                        <div>
                            <label class="block text-[11px] font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">No Telepon</label>
                            <input 
                                type="tel" 
                                name="no_telepon" 
                                value="<?php echo htmlspecialchars($dataMahasiswa['no_telepon']); ?>"
                                class="profile-input w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none"
                            >
                            <?php if (isset($errors['no_telepon'])): ?>
                            <p class="text-red-500 text-[10px] mt-1 flex items-center gap-1">
                                <i class="fas fa-exclamation-circle text-[9px]"></i>
                                <?php echo htmlspecialchars($errors['no_telepon']); ?>
                            </p>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Tanggal Lahir -->
                        <div>
                            <label class="block text-[11px] font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Tanggal Lahir</label>
                            <input 
                                type="date" 
                                name="tanggal_lahir" 
                                value="<?php echo htmlspecialchars($dataMahasiswa['tanggal_lahir']); ?>"
                                disabled
                                class="w-full px-3.5 py-2.5 bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-500 cursor-not-allowed"
                            >
                        </div>
                        
                        <!-- Tahun Masuk (readonly) -->
                        <div>
                            <label class="block text-[11px] font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Tahun Masuk</label>
                            <input 
                                type="text" 
                                value="<?php echo htmlspecialchars($dataMahasiswa['tahun_masuk']); ?>"
                                disabled
                                class="w-full px-3.5 py-2.5 bg-gray-100 border border-gray-200 rounded-xl text-sm text-gray-500 cursor-not-allowed"
                            >
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="flex gap-3 pt-2">
                            <button type="submit" class="flex-1 bg-gradient-to-r from-[#1F5DAA] to-[#3B82F6] hover:from-[#144A8C] hover:to-[#1F5DAA] text-white font-semibold py-3 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 text-sm">
                                <i class="fas fa-save mr-2 text-xs"></i>Simpan Perubahan
                            </button>
                            <a href="profile.php" class="px-5 py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-xl text-sm font-medium transition-colors flex items-center">
                                Batal
                            </a>
                        </div>
                    </form>
                    
                    <?php else: ?>
                    <!-- View Mode -->
                    <div class="space-y-3">
                        <div class="info-card p-3 rounded-xl border border-gray-100 bg-gray-50/50">
                            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Nama Lengkap</p>
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($dataMahasiswa['nama']); ?></p>
                        </div>
                        
                        <div class="info-card p-3 rounded-xl border border-gray-100 bg-gray-50/50">
                            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">NIM</p>
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($dataMahasiswa['nim']); ?></p>
                        </div>
                        
                        <div class="info-card p-3 rounded-xl border border-gray-100 bg-gray-50/50">
                            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Email</p>
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($dataMahasiswa['email']); ?></p>
                        </div>
                        
                        <div class="info-card p-3 rounded-xl border border-gray-100 bg-gray-50/50">
                            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">No Telepon</p>
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($dataMahasiswa['no_telepon']); ?></p>
                        </div>
                        
                        <div class="info-card p-3 rounded-xl border border-gray-100 bg-gray-50/50">
                            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Tanggal Lahir</p>
                            <p class="text-sm font-medium text-gray-800"><?php echo formatTanggalIndo(str_replace('-', '-', $dataMahasiswa['tanggal_lahir'])); ?></p>
                        </div>
                        
                        <div class="info-card p-3 rounded-xl border border-gray-100 bg-gray-50/50">
                            <p class="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Tahun Masuk</p>
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($dataMahasiswa['tahun_masuk']); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Form ganti password -->
            <div class="animate-fade-in-up" style="animation-delay:.25s;">
                <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                    <h3 class="font-semibold text-gray-800 text-sm mb-3 flex items-center gap-2">
                        <i class="fas fa-lock text-[#EF4444]"></i> Ganti Password
                    </h3>
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="ganti_password" value="1">
                        <?php foreach ([
                            ['password_lama', 'Password Lama'],
                            ['password_baru', 'Password Baru (min. 6 karakter)'],
                            ['konfirmasi',    'Konfirmasi Password Baru'],
                        ] as $f): ?>
                        <div>
                            <label class="block text-[10px] font-semibold text-gray-500 mb-1 uppercase tracking-wide"><?php echo $f[1]; ?></label>
                            <input type="password" name="<?php echo $f[0]; ?>"
                                class="input-field w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none"
                                placeholder="••••••••">
                        </div>
                        <?php endforeach; ?>
                        <button type="submit" class="w-full bg-gradient-to-r from-[#EF4444] to-[#DC2626] text-white font-semibold py-2.5 rounded-xl text-sm shadow-md hover:shadow-lg transition-all">
                            <i class="fas fa-key mr-1"></i> Ubah Password
                        </button>
                    </form>
                </div>
            </div>
    
            <!-- Logout -->
            <div class="animate-fade-in-up" style="animation-delay:.3s;">
                <a href="logout.php"
                class="block w-full text-center bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 font-semibold py-3 rounded-2xl text-sm transition-all">
                    <i class="fas fa-sign-out-alt mr-2"></i> Keluar / Logout
                </a>
            </div>
    
        </main>
    
        <?php renderBottomNav('profile'); ?>
    </div>
</body>
</html>