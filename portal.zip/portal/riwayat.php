<?php
// ============================================================
// RIWAYAT.PHP — Riwayat Presensi (Database Version)
// Fitur: Live search (AJAX/JS), filter mata kuliah & status
// ============================================================
require_once 'koneksi.php';
require_once 'functions.php';

cekLogin();

$dataMahasiswa = getMahasiswa();

// ---- Handle AJAX request untuk live search ----
$isAjax = isset($_GET['ajax']) && $_GET['ajax'] === '1';

$search       = trim($_GET['search']  ?? '');
$filterMatkul = trim($_GET['matkul']  ?? '');
$filterStatus = trim($_GET['status']  ?? '');

$riwayat = getRiwayatPresensi($pdo, $search, $filterMatkul, $filterStatus);
$stat    = hitungStatistik($riwayat);

// Daftar dropdown dari mata kuliah milik kelas ini
$daftarMatkul = getDaftarMataKuliah($pdo);
$daftarStatus = ['Hadir', 'Izin', 'Sakit', 'Alpa'];

// Hitung minggu ke-  (urutan minggu dari tanggal)
function hitungMinggu(string $tanggal): string {
    // Hitung minggu akademik berdasarkan Senin pertama tahun semester
    // Pendekatan sederhana: nomor minggu dalam tahun
    $week = (int) date('W', strtotime($tanggal));
    return 'Minggu ' . $week;
}

// ---- Jika AJAX, return JSON ----
if ($isAjax) {
    header('Content-Type: application/json');
    $rows = [];
    foreach ($riwayat as $item) {
        $rows[] = [
            'tanggal'     => formatTanggalIndo($item['tanggal']),
            'minggu'      => hitungMinggu($item['tanggal']),
            'nama_matkul' => $item['nama_matkul'],
            'tipe'        => $item['tipe'],
            'nama_dosen'  => trim($item['gelar'] . ' ' . $item['nama_dosen']),
            'status'      => $item['status_kehadiran'],
            'jam'         => date('H:i', strtotime($item['waktu_pencatatan'])),
        ];
    }
    echo json_encode(['rows' => $rows, 'stat' => $stat]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Riwayat Presensi - Portal Mahasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @keyframes fadeInUp { from{opacity:0;transform:translateY(15px)} to{opacity:1;transform:translateY(0)} }
        .animate-fade-in-up { animation:fadeInUp .4s ease-out forwards; }
        .table-row-hover { transition:background-color .15s ease; }
        .table-row-hover:hover { background-color:#F8FAFC; }
        .table-scroll::-webkit-scrollbar { height:4px; }
        .table-scroll::-webkit-scrollbar-track { background:#f1f1f1; }
        .table-scroll::-webkit-scrollbar-thumb { background:#c1c1c1; border-radius:4px; }
        .filter-input:focus { border-color:#1F5DAA; box-shadow:0 0 0 3px rgba(31,93,170,.1); }
        .status-hadir      { background:#DCFCE7;color:#166534; }
        .status-izin       { background:#DBEAFE;color:#1D4ED8; }
        .status-sakit      { background:#FEF9C3;color:#854D0E; }
        .status-alpa       { background:#FEE2E2;color:#991B1B; }
        #tableBody tr { animation:fadeInUp .2s ease-out; }
        .skeleton { background:linear-gradient(90deg,#f0f0f0 25%,#e0e0e0 50%,#f0f0f0 75%);background-size:200% 100%;animation:shimmer 1s infinite; }
        @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
    </style>
</head>
<body class="bg-gray-50 pb-16 lg:pb-0 text-gray-800">

    <?php renderBottomNav('riwayat'); ?>

    <div id="mainContentWrapper" class="w-full lg:pl-64 min-h-screen transition-all duration-300">
        <div class="w-full bg-white min-h-screen shadow-sm flex flex-col">
            <?php renderHeader('PORTAL MAHASISWA', 'Sistem Presensi'); ?>

    <div class="px-4 pt-3">
        <?php renderFlashMessage(); ?>
    </div>

    <main class="px-4 py-3 space-y-4">

        <!-- Judul -->
        <div class="animate-fade-in-up" style="animation-delay:.05s;">
            <h2 class="text-xl font-bold text-gray-900">Riwayat Presensi</h2>
            <p class="text-[11px] text-gray-400 mt-0.5">Lihat dan pantau kehadiran Anda di setiap Mata Kuliah</p>
        </div>

        <!-- Live Search Bar -->
        <div class="animate-fade-in-up" style="animation-delay:.1s;">
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <i class="fas fa-search text-gray-400 text-sm"></i>
                </div>
                <input type="text" id="searchInput"
                       value="<?php echo htmlspecialchars($search); ?>"
                       placeholder="Cari Mata Kuliah atau Dosen..."
                       class="filter-input w-full pl-10 pr-10 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none transition-all">
                <button id="clearSearch" class="absolute inset-y-0 right-0 pr-3 flex items-center <?php echo $search ? '' : 'hidden'; ?>">
                    <i class="fas fa-times text-gray-400 text-sm hover:text-gray-600"></i>
                </button>
            </div>
            <p class="text-[10px] text-gray-400 mt-1 ml-1">Ketik untuk memfilter hasil secara langsung</p>
        </div>

        <!-- Statistik ringkasan (diupdate via JS) -->
        <div class="animate-fade-in-up" style="animation-delay:.15s;">
            <div class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <h3 class="font-bold text-gray-900 text-base mb-4" id="statTitle">
                    <?php echo $search ? 'Hasil: "' . htmlspecialchars($search) . '"' : 'Semua Presensi'; ?>
                </h3>
                <div class="space-y-3 mb-5">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <i class="far fa-check-circle text-green-500 text-lg"></i>
                            <span class="text-gray-500 font-medium">Hadir</span>
                        </div>
                        <span class="text-gray-600 font-semibold" id="statHadir"><?php echo $stat['hadir']; ?></span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <i class="far fa-calendar-check text-blue-400 text-lg"></i>
                            <span class="text-gray-500 font-medium">Izin</span>
                        </div>
                        <span class="text-gray-600 font-semibold" id="statIzin"><?php echo $stat['izin']; ?></span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-notes-medical text-yellow-400 text-lg"></i>
                            <span class="text-gray-500 font-medium">Sakit</span>
                        </div>
                        <span class="text-gray-600 font-semibold" id="statSakit"><?php echo $stat['sakit']; ?></span>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <i class="far fa-times-circle text-red-500 text-lg"></i>
                            <span class="text-gray-500 font-medium">Alpa</span>
                        </div>
                        <span class="text-gray-600 font-semibold" id="statAlpa"><?php echo $stat['alpa']; ?></span>
                    </div>
                </div>
                <div class="pt-4 border-t border-gray-100">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-[10px] font-semibold text-gray-600">Persentase Kehadiran</span>
                        <span class="text-[11px] font-bold text-[#1F5DAA]" id="statPersen"><?php echo $stat['persentase']; ?>%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2.5">
                        <div class="bg-gradient-to-r from-green-400 to-green-500 h-2.5 rounded-full transition-all duration-500" id="statBar" style="width:<?php echo $stat['persentase']; ?>%"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter lanjutan -->
        <div class="animate-fade-in-up" style="animation-delay:.2s;">
            <div class="flex gap-3">
                <!-- Filter Mata Kuliah -->
                <div class="flex-1">
                    <label class="block text-[10px] font-semibold text-gray-500 mb-1 uppercase tracking-wide">Mata Kuliah</label>
                    <div class="relative">
                        <select id="filterMatkul" class="filter-input w-full pl-3 pr-8 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none appearance-none">
                            <option value="">Semua</option>
                            <?php foreach ($daftarMatkul as $mk): ?>
                            <option value="<?php echo htmlspecialchars($mk); ?>" <?php echo $filterMatkul === $mk ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($mk); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                            <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
                        </div>
                    </div>
                </div>
                <!-- Filter Status -->
                <div class="flex-1">
                    <label class="block text-[10px] font-semibold text-gray-500 mb-1 uppercase tracking-wide">Status</label>
                    <div class="relative">
                        <select id="filterStatus" class="filter-input w-full pl-3 pr-8 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none appearance-none">
                            <option value="">Semua</option>
                            <?php foreach ($daftarStatus as $st): ?>
                            <option value="<?php echo $st; ?>" <?php echo $filterStatus === $st ? 'selected' : ''; ?>>
                                <?php echo $st; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                            <i class="fas fa-chevron-down text-gray-400 text-xs"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Jumlah hasil -->
        <div class="flex items-center gap-2 text-[11px] text-gray-500 animate-fade-in-up" id="resultCount" style="animation-delay:.22s;">
            <i class="fas fa-info-circle text-[#3B82F6]"></i>
            <span>Menampilkan <span id="countNum"><?php echo count($riwayat); ?></span> data</span>
        </div>

        <!-- Tabel riwayat -->
        <div class="animate-fade-in-up" style="animation-delay:.25s;">
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="overflow-x-auto table-scroll">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="bg-gradient-to-r from-[#144A8C] to-[#1F5DAA]">
                                <th class="px-3 py-3 text-[11px] font-semibold text-white uppercase tracking-wider whitespace-nowrap">Tanggal</th>
                                <th class="px-3 py-3 text-[11px] font-semibold text-white uppercase tracking-wider whitespace-nowrap">Minggu</th>
                                <th class="px-3 py-3 text-[11px] font-semibold text-white uppercase tracking-wider whitespace-nowrap">Mata Kuliah</th>
                                <th class="px-3 py-3 text-[11px] font-semibold text-white uppercase tracking-wider whitespace-nowrap">Dosen</th>
                                <th class="px-3 py-3 text-[11px] font-semibold text-white uppercase tracking-wider whitespace-nowrap text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100" id="tableBody">
                            <?php if (count($riwayat) > 0): ?>
                                <?php foreach ($riwayat as $idx => $item):
                                    $stLower = strtolower($item['status_kehadiran']);
                                    $stClass = 'status-' . ($stLower === 'alpa' ? 'alpa' : $stLower);
                                ?>
                                <tr class="table-row-hover" style="animation-delay:<?php echo $idx * 0.02; ?>s;">
                                    <td class="px-3 py-3 text-[11px] text-gray-700 whitespace-nowrap"><?php echo formatTanggalIndo($item['tanggal']); ?></td>
                                    <td class="px-3 py-3 text-[11px] text-gray-600 whitespace-nowrap"><?php echo hitungMinggu($item['tanggal']); ?></td>
                                    <td class="px-3 py-3 text-[11px] text-gray-800 font-medium whitespace-nowrap">
                                        <?php echo htmlspecialchars($item['nama_matkul']); ?>
                                        <span class="text-gray-400 font-normal">(<?php echo $item['tipe']; ?>)</span>
                                    </td>
                                    <td class="px-3 py-3 text-[11px] text-gray-600 whitespace-nowrap">
                                        <?php echo htmlspecialchars(trim($item['nama_dosen'] . ', ' . $item['gelar'])); ?>
                                    </td>
                                    <td class="px-3 py-3 text-center whitespace-nowrap">
                                        <span class="<?php echo $stClass; ?> text-[10px] font-semibold px-2.5 py-1 rounded-lg inline-block">
                                            <?php echo $item['status_kehadiran']; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                            <tr id="emptyRow">
                                <td colspan="5" class="px-4 py-8 text-center">
                                    <div class="flex flex-col items-center gap-2 text-gray-400">
                                        <i class="fas fa-inbox text-3xl mb-1"></i>
                                        <p class="text-sm font-medium">Tidak ada data presensi</p>
                                        <p class="text-[11px]">Coba ubah filter atau kata kunci pencarian</p>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="px-4 py-3 border-t border-gray-100 bg-gray-50/50 flex items-center justify-between">
                    <span class="text-[10px] text-gray-500" id="footerCount"><?php echo count($riwayat); ?> data ditampilkan</span>
                    <span class="text-[10px] text-gray-400">Portal Absensi</span>
                </div>
            </div>
        </div>

    </main>

    <?php renderBottomNav('riwayat'); ?>
</div>

<!-- JavaScript Live Search (AJAX) -->
<script>
const searchInput  = document.getElementById('searchInput');
const clearBtn     = document.getElementById('clearSearch');
const filterMatkul = document.getElementById('filterMatkul');
const filterStatus = document.getElementById('filterStatus');
const tableBody    = document.getElementById('tableBody');

let debounceTimer;

function statusClass(status) {
    const map = { Hadir:'status-hadir', Izin:'status-izin', Sakit:'status-sakit', Alpa:'status-alpa' };
    return map[status] || 'status-alpa';
}

function updateStats(stat) {
    document.getElementById('statHadir').textContent = stat.hadir;
    document.getElementById('statIzin').textContent  = stat.izin;
    document.getElementById('statSakit').textContent = stat.sakit;
    document.getElementById('statAlpa').textContent  = stat.alpa;
    document.getElementById('statPersen').textContent= stat.persentase + '%';
    document.getElementById('statBar').style.width   = stat.persentase + '%';
    document.getElementById('countNum').textContent  = stat.total;
    document.getElementById('footerCount').textContent = stat.total + ' data ditampilkan';
}

function renderRows(rows) {
    if (rows.length === 0) {
        tableBody.innerHTML = `
            <tr><td colspan="5" class="px-4 py-8 text-center">
                <div class="flex flex-col items-center gap-2 text-gray-400">
                    <i class="fas fa-inbox text-3xl mb-1"></i>
                    <p class="text-sm font-medium">Tidak ada data presensi</p>
                    <p class="text-[11px]">Coba ubah filter atau kata kunci pencarian</p>
                </div>
            </td></tr>`;
        return;
    }
    tableBody.innerHTML = rows.map(item => `
        <tr class="table-row-hover">
            <td class="px-3 py-3 text-[11px] text-gray-700 whitespace-nowrap">${item.tanggal}</td>
            <td class="px-3 py-3 text-[11px] text-gray-600 whitespace-nowrap">${item.minggu}</td>
            <td class="px-3 py-3 text-[11px] text-gray-800 font-medium whitespace-nowrap">
                ${escHtml(item.nama_matkul)} <span class="text-gray-400 font-normal">(${item.tipe})</span>
            </td>
            <td class="px-3 py-3 text-[11px] text-gray-600 whitespace-nowrap">${escHtml(item.nama_dosen)}</td>
            <td class="px-3 py-3 text-center whitespace-nowrap">
                <span class="${statusClass(item.status)} text-[10px] font-semibold px-2.5 py-1 rounded-lg inline-block">
                    ${item.status}
                </span>
            </td>
        </tr>
    `).join('');
}

function escHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
}

async function fetchRiwayat() {
    const search = searchInput.value.trim();
    const matkul = filterMatkul.value;
    const status = filterStatus.value;

    // Skeleton loading
    tableBody.innerHTML = `<tr><td colspan="5" class="px-4 py-6 text-center">
        <div class="flex justify-center gap-2">
            <div class="skeleton w-16 h-3 rounded"></div>
            <div class="skeleton w-24 h-3 rounded"></div>
            <div class="skeleton w-20 h-3 rounded"></div>
        </div>
    </td></tr>`;

    const url = `riwayat.php?ajax=1&search=${encodeURIComponent(search)}&matkul=${encodeURIComponent(matkul)}&status=${encodeURIComponent(status)}`;

    try {
        const resp = await fetch(url);
        const data = await resp.json();
        renderRows(data.rows);
        updateStats(data.stat);
        document.getElementById('statTitle').textContent =
            search ? `Hasil: "${search}"` : (matkul || 'Semua Presensi');
        clearBtn.classList.toggle('hidden', search === '');
    } catch(e) {
        tableBody.innerHTML = `<tr><td colspan="5" class="px-4 py-4 text-center text-red-400 text-sm">Gagal memuat data</td></tr>`;
    }
}

// Debounce search input
searchInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(fetchRiwayat, 300);
});

clearBtn.addEventListener('click', () => {
    searchInput.value = '';
    fetchRiwayat();
});

filterMatkul.addEventListener('change', fetchRiwayat);
filterStatus.addEventListener('change', fetchRiwayat);
</script>

</body>
</html>